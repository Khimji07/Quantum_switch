#include <stdio.h>
#include <curl/curl.h>

int main(void) {
    CURL *curl;
    CURLcode res;

    curl_global_init(CURL_GLOBAL_ALL);

    curl = curl_easy_init();
    if(curl) {
        curl_easy_setopt(curl, CURLOPT_URL, "https://rudder.dev.qntmnet.com/api/v4/sshkeygenerator");
        curl_easy_setopt(curl, CURLOPT_POST, 1L);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, "AAAAB3NzaC1yc2EAAAADAQABAAABAQDCsm27C24TlLtgSIGfmtZqm2lQg72SMZRSFE9LzIWU7sP04b9TF8PCfExNa9U2wFzJMW2A6fZuWMVSZpJ4kqf3kmhcsuu7UNSMOSvFjNvLREr1S80t0xqiaYNPjUIDtXGGKCkm3NHip8YuAaad9F0uOhNR72mGQb+uuF7SR1MlESnXgrAIdjwrJk9scEIL4NqXYRTz1uUH3anxBUyC7cfpjydTsyTIaRY+2mQHpiY/Ilru0MMGvwnXocLI6ZnFmVK/GudkG1aX3mrebOSFj4K5+evJJ/8OkAJu1mGa/3zzh6BKPHcdBO0V6fMvO+5gHUvC0cqW2eaZ/96lzbEm/RFN");

        res = curl_easy_perform(curl);
        if(res != CURLE_OK) {
            fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(res));
        }

        curl_easy_cleanup(curl);
    }

    curl_global_cleanup();

    return 0;
}
