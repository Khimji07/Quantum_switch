#include <stdio.h>
#include <stdlib.h>
#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <dlfcn.h>
#include <string.h>
#include <ctype.h>
#include <arpa/inet.h>

const char *host = "203.0.113.121";
const char *community = "public";

int has_nonprintable_chars(const char *str)
{
    while (*str)
    {
        if (!isprint((unsigned char)*str))
        {
            return 1;
        }
        str++;
    }
    return 0;
}
void portTemplateInfo()
{
    int port_vlan_mode[100];
    int port_STP_root_guard[100];
    int port_BDPU_mode[100];
    int port_Isolation[100];
    char index_name[100][255];
    char port_StormCtrlRate[100][255];
    char port_StormCtrlAction[100][255];
    int port_vlan_mode_count = 0, port_STP_root_guard_count = 0, port_BDPU_mode_count = 0, index_name_count = 0, port_isolation_count = 0, port_StormCtrlRate_count = 0, port_StormCtrlAction_count = 0;
    oid port_vlan_mode_OID[] = {1, 3, 6, 1, 4, 1, 89, 48, 22, 1, 1};
    oid port_root_guard_OID[] = {1, 3, 6, 1, 4, 1, 89, 57, 2, 13, 1, 7, 0};
    oid port_BPDU_OID[] = {1, 3, 6, 1, 4, 1, 89, 57, 2, 24, 1, 1, 0};
    oid index_name_OID[] = {1, 3, 6, 1, 4, 1, 89, 53, 3, 1, 2, 0};
    oid port_Isolation_OID[] = {1, 3, 6, 1, 4, 1, 89, 132, 1, 1, 1, 0};
    oid port_StormCtrlRate_OID[] = {1, 3, 6, 1, 4, 1, 89, 77, 12, 1, 2, 0};
    oid port_StormCtrlAction_OID[] = {1, 3, 6, 1, 4, 1, 89, 77, 12, 1, 4, 0};
    netsnmp_session session, *ss;
    netsnmp_pdu *response, *pdu;
    netsnmp_variable_list *vars;
    SOCK_STARTUP;

    snmp_sess_init(&session);
    session.peername = strdup(host);
    session.version = SNMP_VERSION_2c;
    session.community = (unsigned char *)community;
    session.community_len = strlen(community);

    ss = snmp_open(&session);
    if (!ss)
    {
        snmp_sess_perror("snmpwalk", &session);
        SOCK_CLEANUP;
        exit(1);
    }

    oid name[MAX_OID_LEN];
    size_t name_length;
    pdu = snmp_pdu_create(SNMP_MSG_GETBULK);
    pdu->non_repeaters = 0;
    pdu->max_repetitions = 52;
    name_length = OID_LENGTH(index_name_OID);
    snmp_add_null_var(pdu, index_name_OID, name_length);

    if (snmp_synch_response(ss, pdu, &response) == STAT_SUCCESS)
    {
        if (response->errstat == SNMP_ERR_NOERROR)
        {
            for (vars = response->variables; vars; vars = vars->next_variable)
            {
                snprintf(index_name[index_name_count], sizeof(index_name[index_name_count]), "%s", vars->val.string);
                if (vars->val.string && vars->val_len > 0)
                {
                    index_name_count++;
                }
            }
        }
        else
        {
            fprintf(stderr, "Error in packet.\nReason: %s\n", snmp_errstring(response->errstat));
        }
    }
    else
    {
        fprintf(stderr, "Error in request.\n");
    }

    pdu = snmp_pdu_create(SNMP_MSG_GETBULK);
    pdu->non_repeaters = 0;
    pdu->max_repetitions = 52;
    name_length = sizeof(port_vlan_mode_OID) / sizeof(oid);
    snmp_add_null_var(pdu, port_vlan_mode_OID, name_length);

    if (snmp_synch_response(ss, pdu, &response) == STAT_SUCCESS)
    {
        if (response->errstat == SNMP_ERR_NOERROR)
        {

            // Determine the number of ports from the response
            for (vars = response->variables; vars; vars = vars->next_variable)
            {
                port_vlan_mode_count++; // Increment port count
            }

            // Process the response and store port VLAN mode data
            int index = 0;
            for (vars = response->variables; vars && index < port_vlan_mode_count; vars = vars->next_variable)
            {
                // Store the retrieved value in the array
                port_vlan_mode[index++] = *vars->val.integer;
            }
        }
        else
        {
            fprintf(stderr, "Error in packet.\nReason: %s\n", snmp_errstring(response->errstat));
        }
    }
    else
    {
        fprintf(stderr, "Error in request.\n");
    }
    // Print the values stored in the array
    // for (int i = 0; i < port_vlan_mode_count; ++i)
    // {
    //     printf("Port Index-%d : %d\n", i + 1, port_vlan_mode[i]);
    // }

    pdu = snmp_pdu_create(SNMP_MSG_GETBULK);
    pdu->non_repeaters = 0;
    pdu->max_repetitions = 52;
    name_length = sizeof(port_root_guard_OID) / sizeof(oid);
    snmp_add_null_var(pdu, port_root_guard_OID, name_length);

    if (snmp_synch_response(ss, pdu, &response) == STAT_SUCCESS)
    {
        if (response->errstat == SNMP_ERR_NOERROR)
        {

            // Determine the number of ports from the response
            for (vars = response->variables; vars; vars = vars->next_variable)
            {
                port_STP_root_guard_count++; // Increment port count
            }
            // Process the response and store port VLAN mode data
            int index = 0;
            for (vars = response->variables; vars && index < port_vlan_mode_count; vars = vars->next_variable)
            {
                // Store the retrieved value in the array
                port_STP_root_guard[index++] = *vars->val.integer;
            }
        }
        else
        {
            fprintf(stderr, "Error in packet.\nReason: %s\n", snmp_errstring(response->errstat));
        }
    }
    else
    {
        fprintf(stderr, "Error in request.\n");
    }

    pdu = snmp_pdu_create(SNMP_MSG_GETBULK);
    pdu->non_repeaters = 0;
    pdu->max_repetitions = 52;
    name_length = sizeof(port_BPDU_OID) / sizeof(oid);
    snmp_add_null_var(pdu, port_BPDU_OID, name_length);

    if (snmp_synch_response(ss, pdu, &response) == STAT_SUCCESS)
    {
        if (response->errstat == SNMP_ERR_NOERROR)
        {

            // Determine the number of ports from the response
            for (vars = response->variables; vars; vars = vars->next_variable)
            {
                port_BDPU_mode_count++; // Increment port count
            }
            // Process the response and store port VLAN mode data
            int index = 0;
            for (vars = response->variables; vars && index < port_vlan_mode_count; vars = vars->next_variable)
            {
                // Store the retrieved value in the array
                port_BDPU_mode[index++] = *vars->val.integer;
            }
        }
        else
        {
            fprintf(stderr, "Error in packet.\nReason: %s\n", snmp_errstring(response->errstat));
        }
    }
    else
    {
        fprintf(stderr, "Error in request.\n");
    }

    pdu = snmp_pdu_create(SNMP_MSG_GETBULK);
    pdu->non_repeaters = 0;
    pdu->max_repetitions = 52;
    name_length = sizeof(port_Isolation_OID) / sizeof(oid);
    snmp_add_null_var(pdu, port_Isolation_OID, name_length);

    if (snmp_synch_response(ss, pdu, &response) == STAT_SUCCESS)
    {
        if (response->errstat == SNMP_ERR_NOERROR)
        {

            // Determine the number of ports from the response
            for (vars = response->variables; vars; vars = vars->next_variable)
            {
                port_isolation_count++; // Increment port count
            }

            // Process the response and store port VLAN mode data
            int index = 0;
            for (vars = response->variables; vars && index < port_vlan_mode_count; vars = vars->next_variable)
            {
                // Store the retrieved value in the array
                port_Isolation[index++] = *vars->val.integer;
            }
        }
        else
        {
            fprintf(stderr, "Error in packet.\nReason: %s\n", snmp_errstring(response->errstat));
        }
    }
    else
    {
        fprintf(stderr, "Error in request.\n");
    }

    int lastValidIndex = 0;
    for (int i = 0; i < 52; i++)
    {
        if (strlen(index_name[i]) > 0 && !has_nonprintable_chars(index_name[i]))
        {
            lastValidIndex = i;
        }
    }
    printf("{\n");
    for (int i = 0; i <= lastValidIndex; i++)
    {
        // Check if the index name is not empty (length > 0)
        if (strlen(index_name[i]) > 0 && !has_nonprintable_chars(index_name[i]))
        {
            printf("  \"%s\": {\n", index_name[i]);
            printf("    \"VLAN_MODE\": %d,\n", port_vlan_mode[i]);
            printf("    \"STP_ROOT_GUARD\": %d,\n", port_STP_root_guard[i]);
            printf("    \"STP_BPDU_GUARD\": %d,\n", port_BDPU_mode[i]);
            printf("    \"Port Isolation\": %d\n", port_Isolation[i]);
            printf("  }");
            if (i < lastValidIndex)
            {
                printf(",");
            }
            printf("\n");
        }
    }
    printf("}\n");

    snmp_free_pdu(response);
    snmp_close(ss);
    SOCK_CLEANUP;
}

void portTemplateStormCtrl()
{

    int port_StormCtrlRate_broadcast[100];
    int port_StormCtrlRate_multicastReg[100];
    int port_StormCtrlRate_multicastUnreg[100];
    int port_StormCtrlRate_multicastAll[100];
    int port_StormCtrlRate_Unicast[100];
    int port_StormCtrlRate_All[100];
    char port_StormCtrlAction[100];
    int port_StormCtrlRate_b_count = 0, port_StormCtrlRate_mr_count = 0, port_StormCtrlRate_mu_count = 0, port_StormCtrlRate_ma_count = 0, port_StormCtrlRate_a_count = 0, port_StormCtrlRate_Unicast_count=0;
    oid port_StormCtrlRate_OID[] = {1, 3, 6, 1, 4, 1, 89, 77, 12, 1, 2, 0};
    oid port_StormCtrlAction_OID[] = {1, 3, 6, 1, 4, 1, 89, 77, 12, 1, 4, 0};
    netsnmp_session session, *ss;
    netsnmp_pdu *response, *pdu;
    netsnmp_variable_list *vars;
    SOCK_STARTUP;

    snmp_sess_init(&session);
    session.peername = strdup(host);
    session.version = SNMP_VERSION_2c;
    session.community = (unsigned char *)community;
    session.community_len = strlen(community);

    ss = snmp_open(&session);
    if (!ss)
    {
        snmp_sess_perror("snmpwalk", &session);
        SOCK_CLEANUP;
        exit(1);
    }

    oid name[MAX_OID_LEN];
    size_t name_length;

    memmove(name, port_StormCtrlRate_OID, sizeof(port_StormCtrlRate_OID));
    name_length = sizeof(port_StormCtrlRate_OID) / sizeof(oid);
    int count = 0;
    while (1 && count<=312)
  {
    pdu = snmp_pdu_create(SNMP_MSG_GETNEXT);
    snmp_add_null_var(pdu, name, name_length);

    // Send SNMP request and receive response
    if (snmp_synch_response(ss, pdu, &response) == STAT_SUCCESS)
    {
      // Check if response is valid
      if (response->errstat == SNMP_ERR_NOERROR)
      {
        // Iterate through response variables
        for (vars = response->variables; vars; vars = vars->next_variable)
        {
             switch (vars->name[12])
            {
            case 1:
              port_StormCtrlRate_broadcast[port_StormCtrlRate_b_count++] = *vars->val.integer;
              break;
            case 2:
              port_StormCtrlRate_multicastReg[port_StormCtrlRate_mr_count++] = *vars->val.integer;
              break;
            case 3:
              port_StormCtrlRate_multicastUnreg[port_StormCtrlRate_mu_count++] = *vars->val.integer;
              break;
            case 4:
              port_StormCtrlRate_multicastAll[port_StormCtrlRate_ma_count++] = *vars->val.integer;
              break;
            case 5:
              port_StormCtrlRate_Unicast[port_StormCtrlRate_Unicast_count++] = *vars->val.integer;
              break;
            case 6:
              port_StormCtrlRate_All[port_StormCtrlRate_a_count++] = *vars->val.integer;
              break; 
            }
            count++;
            if (vars->name[10]==3)
            {
                goto end_of_loop;
            }
            
            memmove(name, vars->name, vars->name_length * sizeof(oid));
            name_length = vars->name_length;
        }
      }
      else
      {
        fprintf(stderr, "Error in packet.\nReason: %s\n", snmp_errstring(response->errstat));
        break;
      }
    }
    else
    {
      fprintf(stderr, "Error in request.\n");
      break;
    }

    // Free response PDU
    snmp_free_pdu(response);
  }

end_of_loop:
printf("%d\n",count);
  for (int i = 0; i < port_StormCtrlRate_a_count; i++)
  {
    printf("Broadcast:%d\n",port_StormCtrlRate_broadcast[i]);
  }
  
  snmp_close(ss);
  SOCK_CLEANUP;
}

int main()
{
    portTemplateInfo();
    // portTemplateStormCtrl();
    return 0;
}
