#include <sysrepo.h>
#include <sysrepo/xpath.h>
#include <libyang/libyang.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <stdbool.h>
#include <inttypes.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/types.h>
#include <fcntl.h>
#include <signal.h>

#define MIYAGI_SOCK_PATH "/var/run/roscmd.sock"
#define TIMEOUT_SEC 2

static void route_ip(const char *ip_address, const char *subnet_mask, const char *gateway)
{
    int sock;
    struct sockaddr_un addr;
    char cmd[256];

    sock = socket(AF_UNIX, SOCK_STREAM, 0);
    if (sock < 0)
    {
        perror("socket");
        fprintf(stderr, "Failed to create socket\n");
        return;
    }

    memset(&addr, 0, sizeof(struct sockaddr_un));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, MIYAGI_SOCK_PATH, sizeof(addr.sun_path) - 1);

    if (connect(sock, (struct sockaddr *)&addr, sizeof(struct sockaddr_un)) < 0)
    {
        perror("connect");
        fprintf(stderr, "Failed to connect to %s\n", MIYAGI_SOCK_PATH);
        close(sock);
        return;
    }

    if (write(sock, "quantum\n", strlen("quantum\n")) < 0)
    {
        perror("write");
        close(sock);
        return;
    }
    if (write(sock, "yToSJATiy1bz\n", strlen("yToSJATiy1bz\n")) < 0)
    {
        perror("write");
        close(sock);
        return;
    }
    if (write(sock, "configure\n", strlen("configure\n")) < 0)
    {
        perror("write");
        close(sock);
        return;
    }
    usleep(500000); // sleep for 0.5 seconds
    snprintf(cmd, sizeof(cmd), "ip route %s %s %s\n", ip_address, subnet_mask, gateway);
    if (write(sock, cmd, strlen(cmd)) < 0)
    {
        perror("write");
        close(sock);
        return;
    }
    printf("Message sent: %s\n", cmd);
    close(sock);
}

typedef struct
{
    int index[100];
    char ipaddress[128];
    char subnetmask[128];
    char gateway[128];
    bool has_ipaddress;
    bool has_subnetmask;
    bool has_gateway;
} interface_ip_t;

static int module_change_cb(sr_session_ctx_t *session, uint32_t sub_id, const char *module_name, const char *xpath,
                            sr_event_t event, uint32_t request_id, void *private_data)
{
    if (event != SR_EV_DONE)
    {
        return SR_ERR_OK;
    }

    sr_change_iter_t *it = NULL;
    sr_change_oper_t oper;
    sr_val_t *old_val = NULL, *new_val = NULL;
    char path[1024];

    snprintf(path, sizeof(path), "/%s:*//.", module_name);
    sr_get_changes_iter(session, path, &it);

    interface_ip_t ip_info = {0};
    while (sr_get_change_next(session, it, &oper, &old_val, &new_val) == SR_ERR_OK)
    {
        if (new_val && strstr(new_val->xpath, "ip_route"))
        {
            if (sscanf(new_val->xpath, "/ip_route:ip_route_config/routes[index='%d']/%", ip_info.index) == 1)
            {
                if (strstr(new_val->xpath, "ip-address") && new_val->type == SR_STRING_T)
                {
                    strncpy(ip_info.ipaddress, new_val->data.string_val, sizeof(ip_info.ipaddress) - 1);
                    ip_info.has_ipaddress = true;
                }
                else if (strstr(new_val->xpath, "subnet-mask") && new_val->type == SR_STRING_T)
                {
                    strncpy(ip_info.subnetmask, new_val->data.string_val, sizeof(ip_info.subnetmask) - 1);
                    ip_info.has_subnetmask = true;
                }
                else if (strstr(new_val->xpath, "gateway") && new_val->type == SR_STRING_T)
                {
                    strncpy(ip_info.gateway, new_val->data.string_val, sizeof(ip_info.gateway) - 1);
                    ip_info.has_gateway = true;
                }

                if (ip_info.has_ipaddress && ip_info.has_subnetmask && ip_info.has_gateway)
                {
                    printf("IP address: %s\nSubnet Mask: %s\nGateway: %s\n",
                        ip_info.ipaddress, ip_info.subnetmask, ip_info.gateway);
                    route_ip(ip_info.ipaddress, ip_info.subnetmask, ip_info.gateway);
                    memset(&ip_info, 0, sizeof(ip_info)); // Reset for the next route
                }
            }
        }
        sr_free_val(old_val);
        sr_free_val(new_val);
    }

    sr_free_change_iter(it);
    return SR_ERR_OK;
}

int main(int argc, char **argv)
{
    sr_conn_ctx_t *connection = NULL;
    sr_session_ctx_t *session = NULL;
    sr_subscription_ctx_t *subscription = NULL;
    int rc = SR_ERR_OK;

    printf("Application will connect to Sysrepo\n");

    // Connect to sysrepo
    rc = sr_connect(SR_CONN_DEFAULT, &connection);
    if (rc != SR_ERR_OK)
    {
        goto cleanup;
    }

    // Start session
    rc = sr_session_start(connection, SR_DS_RUNNING, &session);
    if (rc != SR_ERR_OK)
    {
        goto cleanup;
    }
    // Subscribe to module changes
    rc = sr_module_change_subscribe(session, "ip_route", NULL, module_change_cb, NULL, 0, SR_SUBSCR_DEFAULT, &subscription);
    if (rc != SR_ERR_OK)
    {
        goto cleanup;
    }

    // Loop until error
    printf("Application will listen for events\n");
    while (1)
    {
        sleep(1000); // or use pause() to wait for signals
    }

cleanup:
    if (subscription)
    {
        sr_unsubscribe(subscription);
    }
    if (session)
    {
        sr_session_stop(session);
    }
    if (connection)
    {
        sr_disconnect(connection);
    }
    return rc;
}
