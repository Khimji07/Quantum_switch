#include <stdio.h>
#include <stdlib.h>
#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <dlfcn.h>
#include <string.h>

typedef void (*SnmpFunction)(void);
const char *host = "172.16.100.17";
const char *community = "public";

void voice_vlan()
{

    char index_name[100][255];
    char index[100][255];
    char vv_enable[100][255];
    char vv_activated[100][255];
    char vv_cosmode[100][255];
    char oui_desc[100][255];
    int index_name_count = 0, vv_enable_count = 0, oui_desc_count = 0, index_count = 0, vv_activated_count = 0, vv_cosmode_count = 0;
    oid index_OID[] = {1, 3, 6, 1, 4, 1, 89, 53, 3, 1, 1};
    oid index_name_OID[] = {1, 3, 6, 1, 4, 1, 89, 53, 3, 1, 2};
    oid vv_enable_OID[] = {1, 3, 6, 1, 4, 1, 89, 48, 54, 12, 5, 1, 1};
    oid vv_activated_OID[] = {1, 3, 6, 1, 4, 1, 89, 48, 54, 12, 5, 1, 4};
    oid vv_cosmode_OID[] = {1, 3, 6, 1, 4, 1, 89, 48, 54, 12, 5, 1, 5};
    oid oui_desc_OID[] = {1, 3, 6, 1, 4, 1, 89, 48, 54, 12, 4, 1, 2};
    oid aging_timeout_OID[] = {1, 3, 6, 1, 4, 1, 89, 48, 54, 12, 6, 0};
    oid vv_state_OID[] = {1, 3, 6, 1, 4, 1, 89, 48, 54, 6, 0};
    oid vv_id_OID[] = {1, 3, 6, 1, 4, 1, 89, 48, 54, 8, 0};
    netsnmp_session session, *ss;
    netsnmp_pdu *response, *pdu;
    netsnmp_variable_list *vars;

    SOCK_STARTUP;

    snmp_sess_init(&session);
    session.peername = strdup(host);
    session.version = SNMP_VERSION_2c;
    session.community = (unsigned char *)community;
    session.community_len = strlen(community);

    ss = snmp_open(&session);
    if (!ss)
    {
        snmp_sess_perror("snmpwalk", &session);
        SOCK_CLEANUP;
        exit(1);
    }
    int aging_timeout, vv_id, vv_state;
    size_t vv_state_length = sizeof(vv_state_OID) / sizeof(oid);
    size_t aging_timeout_length = sizeof(aging_timeout_OID) / sizeof(oid);
    size_t vv_id_length = sizeof(vv_id_OID) / sizeof(oid);
    pdu = snmp_pdu_create(SNMP_MSG_GET);
    snmp_add_null_var(pdu, aging_timeout_OID, aging_timeout_length);

    if (snmp_synch_response(ss, pdu, &response) == STAT_SUCCESS)
    {
        for (vars = response->variables; vars; vars = vars->next_variable)
        {
            // Print the value
            // printf("Aging TimeOut: ");
            switch (vars->type)
            {
            case ASN_INTEGER:
                // printf("%ld", *vars->val.integer);
                aging_timeout = *vars->val.integer;
                break;
            case ASN_OCTET_STR:
                // printf("%s", vars->val.string);
                aging_timeout = vars->val.string;
                break;
                // Handle other data types as needed

            default:
                printf("Unsupported data type: %d", vars->type);
                break;
            }
        }
    }
    else
    {
        fprintf(stderr, "Error in SNMP GET request.\n");
    }
    pdu = snmp_pdu_create(SNMP_MSG_GET);
    snmp_add_null_var(pdu, vv_id_OID, vv_id_length);

    if (snmp_synch_response(ss, pdu, &response) == STAT_SUCCESS)
    {
        for (vars = response->variables; vars; vars = vars->next_variable)
        {
            // Print the value
            switch (vars->type)
            {
            case ASN_INTEGER:
                vv_id = *vars->val.integer;
                break;
            case ASN_OCTET_STR:
                vv_id = vars->val.string;
                break;
                // Handle other data types as needed

            default:
                printf("Unsupported data type: %d", vars->type);
                break;
            }
        }
    }
    else
    {
        fprintf(stderr, "Error in SNMP GET request.\n");
    }
    pdu = snmp_pdu_create(SNMP_MSG_GET);
    snmp_add_null_var(pdu, vv_state_OID, vv_state_length);

    if (snmp_synch_response(ss, pdu, &response) == STAT_SUCCESS)
    {
        for (vars = response->variables; vars; vars = vars->next_variable)
        {
            // Print the value
            switch (vars->type)
            {
            case ASN_INTEGER:
                vv_state = *vars->val.integer;
                break;
            case ASN_OCTET_STR:
                vv_state = vars->val.string;
                break;
                // Handle other data types as needed

            default:
                printf("Unsupported data type: %d", vars->type);
                break;
            }
        }
    }
    else
    {
        fprintf(stderr, "Error in SNMP GET request.\n");
    }

    // Index
    oid name[MAX_OID_LEN];
    size_t name_length;
    memmove(name, index_OID, sizeof(index_OID));
    name_length = sizeof(index_OID) / sizeof(oid);
    while (1)
    {
        pdu = snmp_pdu_create(SNMP_MSG_GETNEXT);
        snmp_add_null_var(pdu, name, name_length);

        if (snmp_synch_response(ss, pdu, &response) == STAT_SUCCESS)
        {
            if (response->errstat == SNMP_ERR_NOERROR)
            {
                for (vars = response->variables; vars; vars = vars->next_variable)
                {
                    if (vars->name[10] == 1)
                    {
                        // Assuming the value is already an integer
                        int value = *vars->val.integer;

                        // Use snprintf to convert the integer to string
                        snprintf(index[index_count], sizeof(index[index_count]), "%d", value);
                        index_count++;
                    }

                    // Prepare for the next instance in the walk
                    memmove(name, vars->name, vars->name_length * sizeof(oid));
                    name_length = vars->name_length;

                    if (vars->name[10] == 2)
                    {
                        goto end_of_index_loop;
                    }
                }
            }
            else
            {
                fprintf(stderr, "Error in packet.\nReason: %s\n", snmp_errstring(response->errstat));
                break;
            }
        }
        else
        {
            fprintf(stderr, "Error in request.\n");
            break;
        }
        snmp_free_pdu(response);
    }

end_of_index_loop:
    printf("%d",index_count);
    // for (int i = 0; i < index_count; i++)
    // {
    //     printf("%s\n", index[i]);
    // }

    // index_name loop
    memmove(name, index_name_OID, sizeof(index_name_OID));
    name_length = sizeof(index_name_OID) / sizeof(oid);
    while (1)
    {
        pdu = snmp_pdu_create(SNMP_MSG_GETNEXT);
        snmp_add_null_var(pdu, name, name_length);

        if (snmp_synch_response(ss, pdu, &response) == STAT_SUCCESS)
        {
            if (response->errstat == SNMP_ERR_NOERROR)
            {
                for (vars = response->variables; vars; vars = vars->next_variable)
                {
                    if (vars->name[10] == 2)
                    {
                        snprintf(index_name[index_name_count], sizeof(index_name[index_name_count]), "%s", vars->val.string);
                        index_name_count++;
                    }
                    // Prepare for the next instance in the walk
                    memmove(name, vars->name, vars->name_length * sizeof(oid));
                    name_length = vars->name_length;
                    if (vars->name[10] == 3)
                    {
                        goto end_of_index_name_loop;
                    }
                }
            }
            else
            {
                fprintf(stderr, "Error in packet.\nReason: %s\n", snmp_errstring(response->errstat));
                break;
            }
        }
        else
        {
            fprintf(stderr, "Error in request.\n");
            break;
        }
        snmp_free_pdu(response);
    }

end_of_index_name_loop:

    // for (int i = 0; i < index_name_count; i++)
    // {
    //     printf("%s\n", index_name[i]);
    // }

    memmove(name, vv_enable_OID, sizeof(vv_enable_OID));
    name_length = sizeof(vv_enable_OID) / sizeof(oid);

    for (int j=0;j <= index_count;j++)
    {
        pdu = snmp_pdu_create(SNMP_MSG_GETNEXT);
        snmp_add_null_var(pdu, name, name_length);

        if (snmp_synch_response(ss, pdu, &response) == STAT_SUCCESS)
        {
            if (response->errstat == SNMP_ERR_NOERROR)
            {
                for (vars = response->variables; vars; vars = vars->next_variable)
                { 

                        if (vars->name[12] == 1 && vars->name[13] == atoi(index[j]))
                        {
                            // Assuming the value is already an integer
                            int value = *vars->val.integer;

                            // Use snprintf to convert the integer to string
                            snprintf(vv_enable[vv_enable_count], sizeof(vv_enable[vv_enable_count]), "%d", value);
                            vv_enable_count++;
                            
                            // printf("= %d\n", value);
                        }
                        if(vars->name[13] != atoi(index[j])){j--;}
                        memmove(name, vars->name, vars->name_length * sizeof(oid));
                        name_length = vars->name_length; // Adjusted here

                        if (vars->name[12] == 2)
                        {
                            goto end_of_enable_loop;
                        }
                    
                }
            }
            else
            {
                fprintf(stderr, "Error in packet.\nReason: %s\n", snmp_errstring(response->errstat));
                break;
            }
        }
        else
        {
            fprintf(stderr, "Error in request.\n");
            break;
        }
        snmp_free_pdu(response);
    }

end_of_enable_loop:
    
    

    memmove(name, vv_activated_OID, sizeof(vv_activated_OID));
    name_length = sizeof(vv_activated_OID) / sizeof(oid);

    for (int j=0;j <= index_count;j++)
    {
        pdu = snmp_pdu_create(SNMP_MSG_GETNEXT);
        snmp_add_null_var(pdu, name, name_length);

        if (snmp_synch_response(ss, pdu, &response) == STAT_SUCCESS)
        {
            if (response->errstat == SNMP_ERR_NOERROR)
            {
                for (vars = response->variables; vars; vars = vars->next_variable)
                {
                        if (vars->name[12] == 4 && vars->name[13] == atoi(index[j]))
                        {
                            // Assuming the value is already an integer
                            int value = *vars->val.integer;

                            // Use snprintf to convert the integer to string
                            snprintf(vv_activated[vv_activated_count], sizeof(vv_activated[vv_activated_count]), "%d", value);
                            vv_activated_count++;
                            // printf("= %d\n", value);
                        }
                        if(vars->name[13] != atoi(index[j])){j--;}
                        memmove(name, vars->name, vars->name_length * sizeof(oid));
                        name_length = vars->name_length; // Adjusted here

                        if (vars->name[12] == 5)
                        {
                            goto end_of_activated_loop;
                        }
                    
                }
            }
            else
            {
                fprintf(stderr, "Error in packet.\nReason: %s\n", snmp_errstring(response->errstat));
                break;
            }
        }
        else
        {
            fprintf(stderr, "Error in request.\n");
            break;
        }
        snmp_free_pdu(response);
    }

end_of_activated_loop:
    
    

    memmove(name, vv_cosmode_OID, sizeof(vv_cosmode_OID));
    name_length = sizeof(vv_cosmode_OID) / sizeof(oid);

    for (int j=0;j <= index_count;j++)
    {
        pdu = snmp_pdu_create(SNMP_MSG_GETNEXT);
        snmp_add_null_var(pdu, name, name_length);

        if (snmp_synch_response(ss, pdu, &response) == STAT_SUCCESS)
        {
            if (response->errstat == SNMP_ERR_NOERROR)
            {
                for (vars = response->variables; vars; vars = vars->next_variable)
                {
                        if (vars->name[12] == 5 && vars->name[13] == atoi(index[j]))
                        {
                            // Assuming the value is already an integer
                            int value = *vars->val.integer;

                            // Use snprintf to convert the integer to string
                            snprintf(vv_cosmode[vv_cosmode_count], sizeof(vv_cosmode[vv_cosmode_count]), "%d", value);
                            vv_cosmode_count++;
                        
                            // printf("= %d\n", value);
                        }
                        if(vars->name[13] != atoi(index[j])){j--;}
                        memmove(name, vars->name, vars->name_length * sizeof(oid));
                        name_length = vars->name_length; // Adjusted here

                        if (vars->name[12] == 6)
                        {
                            goto end_of_cosmode_loop;
                        }
                    
                }
            }
            else
            {
                fprintf(stderr, "Error in packet.\nReason: %s\n", snmp_errstring(response->errstat));
                break;
            }
        }
        else
        {
            fprintf(stderr, "Error in request.\n");
            break;
        }
        snmp_free_pdu(response);
    }

end_of_cosmode_loop:
    

    printf("[\n  ");
    printf("{\n");
    printf("    \"Voice_Vlan_State\":%d,\n    \"Voice_Vlan_Id\":%d,\n    \"Aging_Timeout\":%d\n",vv_state,vv_id,aging_timeout);
    printf("  },\n");
    printf("  {\n");
    for(int i=0;i<index_count;i++)
    {
        printf("    \"%s\":\{\"Voice_Vlan_Enabled\":%s,\n\t\t\"Activation_Status\":%s,\n\t\t\"Cos_Mode\":%s\n\t\t},\n",index_name[i],vv_enable[i],vv_activated[i],vv_cosmode[i]);
    }
    printf("  }\n");
    printf("]\n");
    snmp_close(ss);
    SOCK_CLEANUP;
}

int main()
{
    voice_vlan();
}
