// const char *data = "{\"cloud_identity\": 6, \"serial_number\": \"32117300c6c1\", \"device_type\": \"SWITCH\", \"ssh_key\": \"ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCnaLGpZp79e5ExaT+Fjjb+gMk3ZS69Ga4Rew9YgU4i3illQbeGj+bX29OMzCqXISUiOMkyVoCiEG81tT9IZDa1vz9qwkWUviihmceYixy7+atkz5FHHwp707t/GCEZ4v294F3aASuavLdP3cLJ3oGdZR4wdFi8qQEgJ6BbVLEejEMLsBRyZ2zHIOK/iNl5HI7pR2/uXxDvUEcg8fz4dhsqw/csGeeJfbmQvxF+W0bBey911JDMw/Lov+Mpjlai245wG1sN5BRsiCpFVRWqCkmq9U4zguayu1dUTk1k/vWFY7xcVNf51YJckf2b5H+DNa36xfMQo6vZA7llmXVTjlUf root@MARVELL_LINUX\"}";

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <curl/curl.h>
#include <mbedtls/base64.h>

// Callback function to handle the response from the server
static size_t write_callback(void *contents, size_t size, size_t nmemb, void *userp) {
    size_t realsize = size * nmemb;
    printf("%.*s", (int)realsize, (char *)contents);
    return realsize;
}

int main(void) {
    CURL *curl;
    CURLcode res;

    // Initialize libcurl
    curl_global_init(CURL_GLOBAL_ALL);

    // Create a handle for the request
    curl = curl_easy_init();
    if(curl) {
        struct curl_slist *headers = NULL;

        // Set the request headers
        headers = curl_slist_append(headers, "Content-Type: application/json");
        headers = curl_slist_append(headers, "Authorization: Bearer AccessToken");
        headers = curl_slist_append(headers, "accesstoken: e851df65-7a3f-11ee-9926-90de00353e50");

        // curl_easy_setopt(curl, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);


        // Set the URL for the request
        curl_easy_setopt(curl, CURLOPT_URL, "https://rudder.dev.qntmnet.com/api/v4/sshkeygenerator");

        // Set the request headers
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

        // Set the request data
        const char *data = "{\"cloud_identity\": 6, \"serial_number\": \"32117300c6c1\", \"device_type\": \"SWITCH\", \"ssh_key\": \"ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCnaLGpZp79e5ExaT+Fjjb+gMk3ZS69Ga4Rew9YgU4i3illQbeGj+bX29OMzCqXISUiOMkyVoCiEG81tT9IZDa1vz9qwkWUviihmceYixy7+atkz5FHHwp707t/GCEZ4v294F3aASuavLdP3cLJ3oGdZR4wdFi8qQEgJ6BbVLEejEMLsBRyZ2zHIOK/iNl5HI7pR2/uXxDvUEcg8fz4dhsqw/csGeeJfbmQvxF+W0bBey911JDMw/Lov+Mpjlai245wG1sN5BRsiCpFVRWqCkmq9U4zguayu1dUTk1k/vWFY7xcVNf51YJckf2b5H+DNa36xfMQo6vZA7llmXVTjlUf root@MARVELL_LINUX\"}";
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);

        // Set the callback function to handle the response
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);

        // Disable SSL verification
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);

        // Perform the request
        res = curl_easy_perform(curl);

        // Check for errors
        if(res != CURLE_OK)
            fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(res));

        // Clean up
        curl_slist_free_all(headers);
        curl_easy_cleanup(curl);
    }

    // Cleanup libcurl
    curl_global_cleanup();

    return 0;
}