#include <sysrepo.h>
#include <sysrepo/xpath.h>
#include <libyang/libyang.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <stdbool.h>
#include <errno.h>

#define MIYAGI_SOCK_PATH "/var/run/roscmd.sock"

typedef struct {
    char interface_name[128];
    char stp[128];
    char poe[128];
    bool has_stp;
    bool has_poe;
} feature_t;

static void feature_toggle_int(const char *interface_name, const char *stp, const char *poe)
{
    int sock;
    struct sockaddr_un addr;
    char cmd[256];

    sock = socket(AF_UNIX, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("socket");
        fprintf(stderr, "Failed to create socket\n");
        return;
    }

    memset(&addr, 0, sizeof(struct sockaddr_un));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, MIYAGI_SOCK_PATH, sizeof(addr.sun_path) - 1);

    if (connect(sock, (struct sockaddr *)&addr, sizeof(struct sockaddr_un)) < 0) {
        perror("connect");
        fprintf(stderr, "Failed to connect to %s\n", MIYAGI_SOCK_PATH);
        close(sock);
        return;
    }

    if (write(sock, "quantum\n", strlen("quantum\n")) < 0 ||
        write(sock, "yToSJATiy1bz\n", strlen("yToSJATiy1bz\n")) < 0 ||
        write(sock, "configure\n", strlen("configure\n")) < 0) {
        perror("write");
        close(sock);
        return;
    }

    usleep(500000);

    snprintf(cmd, sizeof(cmd), "int %s\n", interface_name);
    if (write(sock, cmd, strlen(cmd)) < 0) {
        perror("write");
        close(sock);
        return;
    }
    printf("Message sent: %s", cmd);
    usleep(500000);

     if (strcmp(stp, "enable") == 0) {
        snprintf(cmd, sizeof(cmd), "no spanning-tree disable\n");
        if (write(sock, cmd, strlen(cmd)) < 0) {
            perror("write");
            close(sock);
            return;
        }
        printf("Message sent: %s", cmd);
    } else if (strcmp(stp, "disable") == 0) {
        snprintf(cmd, sizeof(cmd), "spanning-tree disable\n");
        if (write(sock, cmd, strlen(cmd)) < 0) {
            perror("write");
            close(sock);
            return;
        }
        printf("Message sent: %s", cmd);
    }

    if (strcmp(poe, "enable") == 0) {
        snprintf(cmd, sizeof(cmd), "power inline auto\n");
        if (write(sock, cmd, strlen(cmd)) < 0) {
            perror("write");
            close(sock);
            return;
        }
        printf("Message sent: %s", cmd);
    } else if (strcmp(stp, "disable") == 0) {
        snprintf(cmd, sizeof(cmd), "power inline never\n");
        if (write(sock, cmd, strlen(cmd)) < 0) {
            perror("write");
            close(sock);
            return;
        }
        printf("Message sent: %s", cmd);
    }

    close(sock);
}



static int module_change_cb(sr_session_ctx_t *session, uint32_t sub_id, const char *module_name, const char *xpath,
                            sr_event_t event, uint32_t request_id, void *private_data)
{
    if (event != SR_EV_DONE) {
        return SR_ERR_OK;
    }

    sr_change_iter_t *it = NULL;
    sr_change_oper_t oper;
    sr_val_t *old_val = NULL, *new_val = NULL;
    char path[1024];
    snprintf(path, sizeof(path), "/%s:*//.", module_name);

    if (sr_get_changes_iter(session, path, &it) != SR_ERR_OK) {
        return SR_ERR_INTERNAL;
    }

    feature_t ft_int;
    memset(&ft_int, 0, sizeof(feature_t)); // Initialize structure

    while (sr_get_change_next(session, it, &oper, &old_val, &new_val) == SR_ERR_OK) {
        if (new_val && strstr(new_val->xpath, "feature_toggle")) {
            if (strstr(new_val->xpath, "name") && new_val->type == SR_STRING_T) {
                strncpy(ft_int.interface_name, new_val->data.string_val, sizeof(ft_int.interface_name) - 1);
                ft_int.interface_name[sizeof(ft_int.interface_name) - 1] = '\0';
            }
            if (strstr(new_val->xpath, "stp") && new_val->type == SR_ENUM_T) {
                strncpy(ft_int.stp, new_val->data.enum_val, sizeof(ft_int.stp) - 1);
                ft_int.stp[sizeof(ft_int.stp) - 1] = '\0';
                ft_int.has_stp = true;
            }
            if (strstr(new_val->xpath, "poe") && new_val->type == SR_ENUM_T) {
                strncpy(ft_int.poe, new_val->data.enum_val, sizeof(ft_int.poe) - 1);
                ft_int.poe[sizeof(ft_int.poe) - 1] = '\0';
                ft_int.has_poe = true;
            }
        }
        if (ft_int.has_stp && ft_int.has_poe) {
            printf("Interface: %s\nSTP: %s\nPOE: %s\n",
                   ft_int.interface_name, ft_int.stp, ft_int.poe);
            feature_toggle_int(ft_int.interface_name, ft_int.stp, ft_int.poe);
            memset(&ft_int, 0, sizeof(ft_int)); // Clear structure after processing
        }

        sr_free_val(old_val);
        sr_free_val(new_val);
    }
    sr_free_change_iter(it);

    return SR_ERR_OK;
}

int main(int argc, char **argv)
{
    sr_conn_ctx_t *connection = NULL;
    sr_session_ctx_t *session = NULL;
    sr_subscription_ctx_t *subscription = NULL;
    int rc = SR_ERR_OK;

    printf("Application will connect to Sysrepo\n");

    rc = sr_connect(SR_CONN_DEFAULT, &connection);
    if (rc != SR_ERR_OK) {
        goto cleanup;
    }

    rc = sr_session_start(connection, SR_DS_RUNNING, &session);
    if (rc != SR_ERR_OK) {
        goto cleanup;
    }

    rc = sr_module_change_subscribe(session, "feature_toggle", NULL, module_change_cb, NULL, 0, SR_SUBSCR_DEFAULT, &subscription);
    if (rc != SR_ERR_OK)
    {
        goto cleanup;
    }

    printf("Application initialized successfully\n");
    while (1) {
        sleep(1000); // Keeps the application running
    }

cleanup:
    if (subscription) {
        sr_unsubscribe(subscription);
    }
    if (session) {
        sr_session_stop(session);
    }
    if (connection) {
        sr_disconnect(connection);
    }
    return rc;
}