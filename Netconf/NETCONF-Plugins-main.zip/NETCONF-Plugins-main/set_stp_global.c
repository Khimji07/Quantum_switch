#include <sysrepo.h>
#include <sysrepo/xpath.h>
#include <libyang/libyang.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <stdbool.h>
#include <errno.h>

#define MIYAGI_SOCK_PATH "/var/run/roscmd.sock"

static void stp_global(const char *mode, int priority, int helloTime, int forwardTime, int maxAge)
{
    int sock;
    struct sockaddr_un addr;
    char cmd[256];

    sock = socket(AF_UNIX, SOCK_STREAM, 0);
    if (sock < 0)
    {
        perror("socket");
        fprintf(stderr, "Failed to create socket\n");
        return;
    }

    memset(&addr, 0, sizeof(struct sockaddr_un));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, MIYAGI_SOCK_PATH, sizeof(addr.sun_path) - 1);

    if (connect(sock, (struct sockaddr *)&addr, sizeof(struct sockaddr_un)) < 0)
    {
        perror("connect");
        fprintf(stderr, "Failed to connect to %s\n", MIYAGI_SOCK_PATH);
        close(sock);
        return;
    }

    if (write(sock, "quantum\n", strlen("quantum\n")) < 0 ||
        write(sock, "yToSJATiy1bz\n", strlen("yToSJATiy1bz\n")) < 0 ||
        write(sock, "configure\n", strlen("configure\n")) < 0)
    {
        perror("write");
        close(sock);
        return;
    }
    usleep(500000);
    snprintf(cmd, sizeof(cmd), "spanning-tree mode %s\n", mode);
    if (write(sock, cmd, strlen(cmd)) < 0)
    {
        perror("write");
        close(sock);
        return;
    }
    printf("Message sent: %s", cmd);

    snprintf(cmd, sizeof(cmd), "spanning-tree priority %d\n", priority);
    if (write(sock, cmd, strlen(cmd)) < 0)
    {
        perror("write");
        close(sock);
        return;
    }
    printf("Message sent: %s", cmd);

    snprintf(cmd, sizeof(cmd), "spanning-tree hello-time %d\n", helloTime);
    if (write(sock, cmd, strlen(cmd)) < 0)
    {
        perror("write");
        close(sock);
        return;
    }
    printf("Message sent: %s", cmd);

    snprintf(cmd, sizeof(cmd), "spanning-tree forward-time %d\n", forwardTime);
    if (write(sock, cmd, strlen(cmd)) < 0)
    {
        perror("write");
        close(sock);
        return;
    }
    printf("Message sent: %s", cmd);

    snprintf(cmd, sizeof(cmd), "spanning-tree max-age %d\n", maxAge);
    if (write(sock, cmd, strlen(cmd)) < 0)
    {
        perror("write");
        close(sock);
        return;
    }
    printf("Message sent: %s", cmd);

    close(sock);
}

typedef struct
{
    int index[100];
    char mode[128];
    int priority;
    int helloTime;
    int forwardTime;
    int maxAge;
    bool has_mode;
    bool has_priority;
    bool has_helloTime;
    bool has_forwardTime;
    bool has_maxAge;
} set_stp_global;

static int module_change_cb(sr_session_ctx_t *session, uint32_t sub_id, const char *module_name, const char *xpath,
                            sr_event_t event, uint32_t request_id, void *private_data)
{
    if (event != SR_EV_DONE)
    {
        return SR_ERR_OK;
    }

    sr_change_iter_t *it = NULL;
    sr_change_oper_t oper;
    sr_val_t *old_val = NULL, *new_val = NULL;
    char path[1024];

    snprintf(path, sizeof(path), "/%s:*//.", module_name);
    sr_get_changes_iter(session, path, &it);

    set_stp_global ssg = {0};
    while (sr_get_change_next(session, it, &oper, &old_val, &new_val) == SR_ERR_OK)
    {
        if (new_val && strstr(new_val->xpath, "stp-interface-global"))
        {
            if (sscanf(new_val->xpath, "/stp-interface-global:set_global/global[index='%d']", ssg.index) == 1)
            {
                if (strstr(new_val->xpath, "stpMode") && new_val->type == SR_ENUM_T)
                {
                    strncpy(ssg.mode, new_val->data.enum_val, sizeof(ssg.mode) - 1);
                    ssg.mode[sizeof(ssg.mode) - 1] = '\0';
                    ssg.has_mode = true;
                }
                else if (strstr(new_val->xpath, "priority") && new_val->type == SR_UINT32_T)
                {
                    ssg.priority = new_val->data.uint32_val;
                    ssg.has_priority = true;
                }
                else if (strstr(new_val->xpath, "helloTime") && new_val->type == SR_UINT8_T)
                {
                    ssg.helloTime = new_val->data.uint8_val;
                    ssg.has_helloTime = true;
                }
                else if (strstr(new_val->xpath, "forwardTime") && new_val->type == SR_UINT8_T)
                {
                    ssg.forwardTime = new_val->data.uint8_val;
                    ssg.has_forwardTime = true;
                }
                else if (strstr(new_val->xpath, "maxAge") && new_val->type == SR_UINT8_T)
                {
                    ssg.maxAge = new_val->data.uint8_val;
                    ssg.has_maxAge = true;
                }
            }
            if (ssg.has_mode && ssg.has_priority && ssg.has_helloTime && ssg.has_forwardTime && ssg.has_maxAge)
            {
                printf("Mode: %s\nPriority: %d\nHello Time: %d\nForward Time: %d\nMax Age: %d\n",
                       ssg.mode, ssg.priority, ssg.helloTime, ssg.forwardTime, ssg.maxAge);
                stp_global(ssg.mode, ssg.priority, ssg.helloTime, ssg.forwardTime, ssg.maxAge);
                memset(&ssg, 0, sizeof(ssg));
            }
        }
        sr_free_val(old_val);
        sr_free_val(new_val);
    }
    sr_free_change_iter(it);
    return SR_ERR_OK;
}
int main(int argc, char **argv)
{
    sr_conn_ctx_t *connection = NULL;
    sr_session_ctx_t *session = NULL;
    sr_subscription_ctx_t *subscription = NULL;
    int rc = SR_ERR_OK;

    printf("Application will connect to Sysrepo\n");

    rc = sr_connect(SR_CONN_DEFAULT, &connection);
    if (rc != SR_ERR_OK)
    {
        goto cleanup;
    }

    rc = sr_session_start(connection, SR_DS_RUNNING, &session);
    if (rc != SR_ERR_OK)
    {
        goto cleanup;
    }

    rc = sr_module_change_subscribe(session, "stp-interface-global", NULL, module_change_cb, NULL, 0, SR_SUBSCR_DEFAULT, &subscription);
    if (rc != SR_ERR_OK)
    {
        goto cleanup;
    }

    printf("Application will listen for events\n");
    while (1)
    {
        sleep(1000);
    }

cleanup:
    if (subscription)
    {
        sr_unsubscribe(subscription);
    }
    if (session)
    {
        sr_session_stop(session);
    }
    if (connection)
    {
        sr_disconnect(connection);
    }
    return rc;
}