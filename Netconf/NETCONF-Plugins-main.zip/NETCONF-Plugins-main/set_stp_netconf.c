#include <sysrepo.h>
#include <sysrepo/xpath.h>
#include <libyang/libyang.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <stdbool.h>
#include <errno.h>

#define MIYAGI_SOCK_PATH "/var/run/roscmd.sock"

typedef struct {
    char interface_name[128];
    int port_priority;
    char portFast[128];
    char guard[128];
    char bpduGuard[128];
    bool has_port_priority;
    bool has_portFast;
    bool has_guard;
    bool has_bpduGuard;
} interface_stp_t;

static void stp_interface(const char *interface_name, int port_priority, const char *portFast, const char *guard, const char *bpduGuard)
{
    int sock;
    struct sockaddr_un addr;
    char cmd[256];

    sock = socket(AF_UNIX, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("socket");
        fprintf(stderr, "Failed to create socket\n");
        return;
    }

    memset(&addr, 0, sizeof(struct sockaddr_un));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, MIYAGI_SOCK_PATH, sizeof(addr.sun_path) - 1);

    if (connect(sock, (struct sockaddr *)&addr, sizeof(struct sockaddr_un)) < 0) {
        perror("connect");
        fprintf(stderr, "Failed to connect to %s\n", MIYAGI_SOCK_PATH);
        close(sock);
        return;
    }

    if (write(sock, "quantum\n", strlen("quantum\n")) < 0 ||
        write(sock, "yToSJATiy1bz\n", strlen("yToSJATiy1bz\n")) < 0 ||
        write(sock, "configure\n", strlen("configure\n")) < 0) {
        perror("write");
        close(sock);
        return;
    }

    usleep(500000);

    snprintf(cmd, sizeof(cmd), "int %s\n", interface_name);
    if (write(sock, cmd, strlen(cmd)) < 0) {
        perror("write");
        close(sock);
        return;
    }
    printf("Message sent: %s", cmd);
    usleep(500000);

    snprintf(cmd, sizeof(cmd), "spanning-tree port-priority %d\n", port_priority);
    if (write(sock, cmd, strlen(cmd)) < 0) {
        perror("write");
        close(sock);
        return;
    }
    printf("Message sent: %s", cmd);

    if (strcmp(portFast, "enable") == 0) {
        snprintf(cmd, sizeof(cmd), "spanning-tree portfast\n");
        if (write(sock, cmd, strlen(cmd)) < 0) {
            perror("write");
            close(sock);
            return;
        }
        printf("Message sent: %s", cmd);
    } else if (strcmp(portFast, "disable") == 0) {
        snprintf(cmd, sizeof(cmd), "no spanning-tree portfast\n");
        if (write(sock, cmd, strlen(cmd)) < 0) {
            perror("write");
            close(sock);
            return;
        }
        printf("Message sent: %s", cmd);
    }

    if (strcmp(guard, "enable") == 0) {
        snprintf(cmd, sizeof(cmd), "spanning-tree guard root\n");
        if (write(sock, cmd, strlen(cmd)) < 0) {
            perror("write");
            close(sock);
            return;
        }
        printf("Message sent: %s", cmd);
    } else if (strcmp(guard, "disable") == 0) {
        snprintf(cmd, sizeof(cmd), "no spanning-tree guard root\n");
        if (write(sock, cmd, strlen(cmd)) < 0) {
            perror("write");
            close(sock);
            return;
        }
        printf("Message sent: %s", cmd);
    }

    if (strcmp(bpduGuard, "enable") == 0) {
        snprintf(cmd, sizeof(cmd), "spanning-tree bpduguard enable\n");
        if (write(sock, cmd, strlen(cmd)) < 0) {
            perror("write");
            close(sock);
            return;
        }
        printf("Message sent: %s", cmd);
    } else if (strcmp(bpduGuard, "disable") == 0) {
        snprintf(cmd, sizeof(cmd), "spanning-tree bpduguard disable\n");
        if (write(sock, cmd, strlen(cmd)) < 0) {
            perror("write");
            close(sock);
            return;
        }
        printf("Message sent: %s", cmd);
    }

    close(sock);
}

static int module_change_cb(sr_session_ctx_t *session, uint32_t sub_id, const char *module_name, const char *xpath,
                            sr_event_t event, uint32_t request_id, void *private_data)
{
    if (event != SR_EV_DONE) {
        return SR_ERR_OK;
    }

    sr_change_iter_t *it = NULL;
    sr_change_oper_t oper;
    sr_val_t *old_val = NULL, *new_val = NULL;
    char path[1024];
    snprintf(path, sizeof(path), "/%s:*//.", module_name);

    if (sr_get_changes_iter(session, path, &it) != SR_ERR_OK) {
        return SR_ERR_INTERNAL;
    }

    interface_stp_t stp_int;
    memset(&stp_int, 0, sizeof(interface_stp_t)); // Initialize structure

    while (sr_get_change_next(session, it, &oper, &old_val, &new_val) == SR_ERR_OK) {
        if (new_val && strstr(new_val->xpath, "stp-interface-set")) {
            if (strstr(new_val->xpath, "name") && new_val->type == SR_STRING_T) {
                strncpy(stp_int.interface_name, new_val->data.string_val, sizeof(stp_int.interface_name) - 1);
                stp_int.interface_name[sizeof(stp_int.interface_name) - 1] = '\0';
            }
            if (strstr(new_val->xpath, "port-priority") && new_val->type == SR_INT32_T) {
                stp_int.port_priority = new_val->data.int32_val;
                stp_int.has_port_priority = true;
            }
            if (strstr(new_val->xpath, "portfast") && new_val->type == SR_ENUM_T) {
                strncpy(stp_int.portFast, new_val->data.enum_val, sizeof(stp_int.portFast) - 1);
                stp_int.portFast[sizeof(stp_int.portFast) - 1] = '\0';
                stp_int.has_portFast = true;
            }
            if (strstr(new_val->xpath, "guard") && new_val->type == SR_ENUM_T) {
                strncpy(stp_int.guard, new_val->data.enum_val, sizeof(stp_int.guard) - 1);
                stp_int.guard[sizeof(stp_int.guard) - 1] = '\0';
                stp_int.has_guard = true;
            }
            if (strstr(new_val->xpath, "bpdu-guard") && new_val->type == SR_ENUM_T) {
                strncpy(stp_int.bpduGuard, new_val->data.enum_val, sizeof(stp_int.bpduGuard) - 1);
                stp_int.bpduGuard[sizeof(stp_int.bpduGuard) - 1] = '\0';
                stp_int.has_bpduGuard = true;
            }
        }



        if (stp_int.has_port_priority && stp_int.has_portFast && stp_int.has_guard && stp_int.has_bpduGuard) {
            printf("Interface: %s\nPort Priority: %d\nPort Fast: %s\nGuard: %s\nBpdu Guard: %s\n",
                   stp_int.interface_name, stp_int.port_priority, stp_int.portFast, stp_int.guard, stp_int.bpduGuard);
            stp_interface(stp_int.interface_name, stp_int.port_priority, stp_int.portFast, stp_int.guard, stp_int.bpduGuard);
            memset(&stp_int, 0, sizeof(stp_int)); // Clear structure after processing
        }

        sr_free_val(old_val);
        sr_free_val(new_val);
    }
    sr_free_change_iter(it);

    return SR_ERR_OK;
}

int main(int argc, char **argv)
{
    sr_conn_ctx_t *connection = NULL;
    sr_session_ctx_t *session = NULL;
    sr_subscription_ctx_t *subscription = NULL;
    int rc = SR_ERR_OK;

    printf("Application will connect to Sysrepo\n");

    rc = sr_connect(SR_CONN_DEFAULT, &connection);
    if (rc != SR_ERR_OK) {
        goto cleanup;
    }

    rc = sr_session_start(connection, SR_DS_RUNNING, &session);
    if (rc != SR_ERR_OK) {
        goto cleanup;
    }

    rc = sr_module_change_subscribe(session, "stp-interface-set", NULL, module_change_cb, NULL, 0, SR_SUBSCR_DEFAULT, &subscription);
    if (rc != SR_ERR_OK)
    {
        goto cleanup;
    }

    printf("Application initialized successfully\n");
    while (1) {
        sleep(1000); // Keeps the application running
    }

cleanup:
    if (subscription) {
        sr_unsubscribe(subscription);
    }
    if (session) {
        sr_session_stop(session);
    }
    if (connection) {
        sr_disconnect(connection);
    }
    return rc;
}
