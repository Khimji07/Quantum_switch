#include <sysrepo.h>
#include <sysrepo/xpath.h>
#include <libyang/libyang.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <stdbool.h>
#include <errno.h>

#define MIYAGI_SOCK_PATH "/var/run/roscmd.sock"

static void set_vlan(int id, const char *description)
{
    int sock;
    struct sockaddr_un addr;
    char cmd[256];

    sock = socket(AF_UNIX, SOCK_STREAM, 0);
    if (sock < 0)
    {
        perror("socket");
        fprintf(stderr, "Failed to create socket\n");
        return;
    }

    memset(&addr, 0, sizeof(struct sockaddr_un));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, MIYAGI_SOCK_PATH, sizeof(addr.sun_path) - 1);

    if (connect(sock, (struct sockaddr *)&addr, sizeof(struct sockaddr_un)) < 0)
    {
        perror("connect");
        fprintf(stderr, "Failed to connect to %s\n", MIYAGI_SOCK_PATH);
        close(sock);
        return;
    }

    if (write(sock, "quantum\n", strlen("quantum\n")) < 0 ||
        write(sock, "yToSJATiy1bz\n", strlen("yToSJATiy1bz\n")) < 0 ||
        write(sock, "configure\n", strlen("configure\n")) < 0)
    {
        perror("write");
        close(sock);
        return;
    }
    usleep(500000);
    snprintf(cmd, sizeof(cmd), "int vlan %d\n", id);
    if (write(sock, cmd, strlen(cmd)) < 0)
    {
        perror("write");
        close(sock);
        return;
    }
    printf("Message sent: %s", cmd);

    snprintf(cmd, sizeof(cmd), "name %s\n", description);
    if (write(sock, cmd, strlen(cmd)) < 0)
    {
        perror("write");
        close(sock);
        return;
    }
    printf("Message sent: %s", cmd);
    close(sock);
}

typedef struct 
{
    int id;
    char description[128];
    bool has_id;
    bool has_description;
} set_vlan_nc;

static int module_change_cb(sr_session_ctx_t *session, uint32_t sub_id, const char *module_name, const char *xpath,
                            sr_event_t event, uint32_t request_id, void *private_data)
{
    if (event != SR_EV_DONE)
    {
        return SR_ERR_OK;
    }

    sr_change_iter_t *it = NULL;
    sr_change_oper_t oper;
    sr_val_t *old_val = NULL, *new_val = NULL;
    char path[1024];

    snprintf(path, sizeof(path), "/%s:*//.", module_name);
    int rc = sr_get_changes_iter(session, path, &it);
    if (rc != SR_ERR_OK)
    {
        fprintf(stderr, "Failed to get changes iterator: %s\n", sr_strerror(rc));
        return rc;
    }

    set_vlan_nc vs;
    memset(&vs, 0, sizeof(vs));

    while (sr_get_change_next(session, it, &oper, &old_val, &new_val) == SR_ERR_OK)
    {
        if (new_val && strstr(new_val->xpath, "vlan[id='"))
        {
            if (sscanf(new_val->xpath, "/vlan_set:set/vlan[id='%d']", &vs.id) == 1)
            {
                if (strstr(new_val->xpath, "id") && new_val->type == SR_UINT16_T)
                {
                    vs.has_id = true;
                }
                else if (strstr(new_val->xpath, "description") && new_val->type == SR_STRING_T)
                {
                    strncpy(vs.description, new_val->data.string_val, sizeof(vs.description) - 1);
                    vs.has_description = true;
                }
            }
            if (vs.has_id && vs.has_description)
            {
                printf("Id: %d\nDescription: %s\n", vs.id, vs.description);
                set_vlan(vs.id, vs.description);
                memset(&vs, 0, sizeof(vs));
            }
        }
        sr_free_val(old_val);
        sr_free_val(new_val);
    }
    sr_free_change_iter(it);
    return SR_ERR_OK;
}

int main(int argc, char **argv)
{
    sr_conn_ctx_t *connection = NULL;
    sr_session_ctx_t *session = NULL;
    sr_subscription_ctx_t *subscription = NULL;
    int rc = SR_ERR_OK;

    printf("Application will connect to Sysrepo\n");

    // Connect to sysrepo
    rc = sr_connect(SR_CONN_DEFAULT, &connection);
    if (rc != SR_ERR_OK)
    {
        goto cleanup;
    }

    // Start session
    rc = sr_session_start(connection, SR_DS_RUNNING, &session);
    if (rc != SR_ERR_OK)
    {
        goto cleanup;
    }
    // Subscribe to module changes
    rc = sr_module_change_subscribe(session, "vlan_set", NULL, module_change_cb, NULL, 0, SR_SUBSCR_DEFAULT, &subscription);
    if (rc != SR_ERR_OK)
    {
        goto cleanup;
    }

    // Loop until error
    printf("Application will listen for events\n");
    while (1)
    {
        sleep(1000); // or use pause() to wait for signals
    }

cleanup:
    if (subscription)
    {
        sr_unsubscribe(subscription);
    }
    if (session)
    {
        sr_session_stop(session);
    }
    if (connection)
    {
        sr_disconnect(connection);
    }
    return rc;
}
