#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <sysrepo.h>
#include <libyang/libyang.h>

// Define constants for SNMP session
#define SNMP_HOST "203.0.113.121"
#define SNMP_COMMUNITY "qnpublic"

// Define SNMP OID for IP addresses
oid indexOid[] = {1, 3, 6, 1, 2, 1, 17, 2, 15, 1, 1, 0};
oid priorityOid[] = {1, 3, 6, 1, 2, 1, 17, 2, 15, 1, 2, 0};
oid stateOid[] = {1, 3, 6, 1, 2, 1, 17, 2, 15, 1, 3, 0};
oid enableOid[] = {1, 3, 6, 1, 2, 1, 17, 2, 15, 1, 4, 0};
oid pathOid[] = {1, 3, 6, 1, 2, 1, 17, 2, 15, 1, 5, 0};
oid stpgOid[] = {1, 3, 6, 1, 2, 1, 17, 2, 1, 0};

int apply_stpg_data_to_data_tree(sr_session_ctx_t *session)
{
    netsnmp_session session_snmp, *ss;
    netsnmp_pdu *response, *pdu;
    netsnmp_variable_list *vars;
    int rc = SR_ERR_OK;
    int index_count = 0, rootCost_count = 0, priority_count = 0, rootPort_count = 0, maxAge_count = 0, helloTime_count = 0, forwardTime_count = 0;
    int index[100], priority[100], rootCost[100], rootPort[100], maxAge[100], helloTime[100], forwardTime[100];
    char xpath[512];

    // Initialize SNMP session
    snmp_sess_init(&session_snmp);
    session_snmp.peername = strdup(SNMP_HOST);
    session_snmp.version = SNMP_VERSION_2c;
    session_snmp.community = (unsigned char *)SNMP_COMMUNITY;
    session_snmp.community_len = strlen(SNMP_COMMUNITY);
    ss = snmp_open(&session_snmp);
    if (!ss)
    {
        snmp_sess_perror("snmpwalk", &session_snmp);
        return SR_ERR_INTERNAL;
    }

    // Prepare SNMP OID for retrieval
    oid name[MAX_OID_LEN];
    size_t name_length;

    memmove(name, stpgOid, sizeof(stpgOid));
    name_length = sizeof(stpgOid) / sizeof(oid);

    // Main SNMP retrieval loop
    while (1)
    {
        pdu = snmp_pdu_create(SNMP_MSG_GETNEXT);
        snmp_add_null_var(pdu, name, name_length);

        // Send SNMP request and handle response
        if (snmp_synch_response(ss, pdu, &response) == STAT_SUCCESS)
        {
            if (response->errstat == SNMP_ERR_NOERROR)
            {
                // Process SNMP response
                for (vars = response->variables; vars; vars = vars->next_variable)
                {
                    if (vars->type == ASN_INTEGER)
                    {
                        switch (vars->name[8])
                        {
                        case 2:
                            priority[priority_count++] = *vars->val.integer;
                            break;
                        case 6:
                            rootCost[rootCost_count++] = *vars->val.integer;
                            break;
                        case 7:
                            rootPort[rootPort_count++] = *vars->val.integer;
                            break;
                        case 12:
                            maxAge[maxAge_count++] = *vars->val.integer;
                            break;
                        case 13:
                            helloTime[helloTime_count++] = *vars->val.integer;
                            break;
                        case 14:
                            forwardTime[forwardTime_count++] = *vars->val.integer;
                            break;
                        }
                    }
                    memmove(name, vars->name, vars->name_length * sizeof(oid));
                    name_length = vars->name_length;
                    // Exit loop on specific OID condition
                    if (vars->name[8] == 15)
                        goto end_of_loop;
                }
            }
            else
            {
                fprintf(stderr, "Error in packet.\nReason: %s\n", snmp_errstring(response->errstat));
                rc = SR_ERR_INTERNAL;
                break;
            }
        }
        else
        {
            fprintf(stderr, "Error in request.\n");
            rc = SR_ERR_INTERNAL;
            break;
        }
        snmp_free_pdu(response);
    }

end_of_loop:
    snmp_close(ss);

    for (int i = 0; i < priority_count; i++)
    {
        index[i] = i + 1;
        index_count++;
    }

    // Handle SNMP data processing
    if (rc == SR_ERR_OK)
    {
        // Apply changes to sysrepo data tree
        for (size_t i = 0; i < index_count; i++)
        {
            // Set XPath for interface container
            snprintf(xpath, sizeof(xpath), "/get_stp_global:stp_global/global[index='%d']", index[i]);

            // Check if the container exists
            sr_val_t *value;
            rc = sr_get_item(session, xpath, 0, &value);
            if (rc == SR_ERR_NOT_FOUND)
            {
                // Container does not exist, create it
                printf("Container does not exist, creating: %s\n", xpath);
                rc = sr_set_item(session, xpath, NULL, SR_EDIT_DEFAULT);
                if (rc != SR_ERR_OK)
                {
                    fprintf(stderr, "Failed to create interface container: %s\n", sr_strerror(rc));
                    return rc;
                }
                else
                {
                    printf("Interface container created successfully: %s\n", xpath);
                }
            }
            else if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Error checking interface container: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                // Container exists, continue
                printf("Container already exists: %s\n", xpath);
            }
            snprintf(xpath, sizeof(xpath), "/get_stp_global:stp_global/global[index='%d']/priority", index[i]);
            sr_val_t priority_val;
            priority_val.type = SR_INT32_T;
            priority_val.data.int32_val = (int32_t)priority[i];
            printf("Setting priority: %s -> %d\n", xpath, priority[i]);
            rc = sr_set_item(session, xpath, &priority_val, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set priority leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("Priority set successfully: %s -> %d\n", xpath, priority[i]);
            }
            snprintf(xpath, sizeof(xpath), "/get_stp_global:stp_global/global[index='%d']/rootCost", index[i]);
            sr_val_t rootCost_val;
            rootCost_val.type = SR_INT32_T;
            rootCost_val.data.int32_val = (int32_t)rootCost[i];
            printf("Setting Root Cost: %s -> %d\n", xpath, rootCost[i]);
            rc = sr_set_item(session, xpath, &rootCost_val, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set Root Cost leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("Root Cost set successfully: %s -> %d\n", xpath, rootCost[i]);
            }
            snprintf(xpath, sizeof(xpath), "/get_stp_global:stp_global/global[index='%d']/rootPort", index[i]);
            sr_val_t rootPort_val;
            rootPort_val.type = SR_INT32_T;
            rootPort_val.data.int32_val = (int32_t)rootPort[i];
            printf("Setting Root Port: %s -> %d\n", xpath, rootPort[i]);
            rc = sr_set_item(session, xpath, &rootPort_val, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set Root Port leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("Root Port set successfully: %s -> %d\n", xpath, rootPort[i]);
            }
            snprintf(xpath, sizeof(xpath), "/get_stp_global:stp_global/global[index='%d']/maxAge", index[i]);
            sr_val_t maxAge_val;
            maxAge_val.type = SR_INT32_T;
            maxAge_val.data.int32_val = (int32_t)maxAge[i];
            printf("Setting Root Port: %s -> %d\n", xpath, maxAge[i]);
            rc = sr_set_item(session, xpath, &maxAge_val, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set Root Port leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("Root Port set successfully: %s -> %d\n", xpath, maxAge[i]);
            }
            snprintf(xpath, sizeof(xpath), "/get_stp_global:stp_global/global[index='%d']/helloTime", index[i]);
            sr_val_t helloTime_val;
            helloTime_val.type = SR_INT32_T;
            helloTime_val.data.int32_val = (int32_t)helloTime[i];
            printf("Setting Root Port: %s -> %d\n", xpath, helloTime[i]);
            rc = sr_set_item(session, xpath, &helloTime_val, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set Root Port leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("Root Port set successfully: %s -> %d\n", xpath, helloTime[i]);
            }
            snprintf(xpath, sizeof(xpath), "/get_stp_global:stp_global/global[index='%d']/forwardTime", index[i]);
            sr_val_t forwardTime_val;
            forwardTime_val.type = SR_INT32_T;
            forwardTime_val.data.int32_val = (int32_t)forwardTime[i];
            printf("Setting Root Port: %s -> %d\n", xpath, forwardTime[i]);
            rc = sr_set_item(session, xpath, &forwardTime_val, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set Forward Time leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("Forward time successfully: %s -> %d\n", xpath, forwardTime[i]);
            }
        }
        rc = sr_apply_changes(session, 0);
        if (rc != SR_ERR_OK)
        {
            fprintf(stderr, "Failed to apply changes to the data tree: %s\n", sr_strerror(rc));
            return rc;
        }
        rc = sr_validate(session, NULL, 0);
        if (rc != SR_ERR_OK)
        {
            fprintf(stderr, "Validation failed: %s\n", sr_strerror(rc));
            return rc;
        }
        else
        {
            printf("Validation succeeded.\n");
        }
        printf("SNMP data successfully set in the data tree.\n");
    }

    return rc;
}

int apply_stp_data_to_data_tree(sr_session_ctx_t *session)
{
    netsnmp_session session_snmp, *ss;
    netsnmp_pdu *response, *pdu;
    netsnmp_variable_list *vars;
    int rc = SR_ERR_OK;
    int index_count = 0, priority_count = 0, state_count = 0, enable_count = 0, path_count = 0;
    int index[100], priority[100], state[100], enable[100], path[100];
    char xpath[512];

    // Initialize SNMP session
    snmp_sess_init(&session_snmp);
    session_snmp.peername = strdup(SNMP_HOST);
    session_snmp.version = SNMP_VERSION_2c;
    session_snmp.community = (unsigned char *)SNMP_COMMUNITY;
    session_snmp.community_len = strlen(SNMP_COMMUNITY);
    ss = snmp_open(&session_snmp);
    if (!ss)
    {
        snmp_sess_perror("snmpwalk", &session_snmp);
        return SR_ERR_INTERNAL;
    }

    // Index
    oid name[MAX_OID_LEN];
    size_t name_length;
    pdu = snmp_pdu_create(SNMP_MSG_GETBULK);
    pdu->non_repeaters = 0;
    pdu->max_repetitions = 52;
    name_length = sizeof(indexOid) / sizeof(oid);
    snmp_add_null_var(pdu, indexOid, name_length);

    // Send SNMP request and handle response
    if (snmp_synch_response(ss, pdu, &response) == STAT_SUCCESS)
    {
        if (response->errstat == SNMP_ERR_NOERROR)
        {
            // Process SNMP response
            for (vars = response->variables; vars; vars = vars->next_variable)
            {
                index[index_count] = *vars->val.integer;
                index_count++;
            }
        }
        else
        {
            fprintf(stderr, "Error in packet.\nReason: %s\n", snmp_errstring(response->errstat));
            rc = SR_ERR_INTERNAL;
        }
    }
    else
    {
        fprintf(stderr, "Error in request.\n");
        rc = SR_ERR_INTERNAL;
    }
    snmp_free_pdu(response);

    pdu = snmp_pdu_create(SNMP_MSG_GETBULK);
    pdu->non_repeaters = 0;
    pdu->max_repetitions = 52;
    name_length = sizeof(priorityOid) / sizeof(oid);
    snmp_add_null_var(pdu, priorityOid, name_length);

    // Send SNMP request and handle response
    if (snmp_synch_response(ss, pdu, &response) == STAT_SUCCESS)
    {
        if (response->errstat == SNMP_ERR_NOERROR)
        {
            // Process SNMP response
            for (vars = response->variables; vars; vars = vars->next_variable)
            {
                priority[priority_count] = *vars->val.integer;
                priority_count++;
            }
        }
        else
        {
            fprintf(stderr, "Error in packet.\nReason: %s\n", snmp_errstring(response->errstat));
            rc = SR_ERR_INTERNAL;
        }
    }
    else
    {
        fprintf(stderr, "Error in request.\n");
        rc = SR_ERR_INTERNAL;
    }
    snmp_free_pdu(response);

    pdu = snmp_pdu_create(SNMP_MSG_GETBULK);
    pdu->non_repeaters = 0;
    pdu->max_repetitions = 52;
    name_length = sizeof(stateOid) / sizeof(oid);
    snmp_add_null_var(pdu, stateOid, name_length);

    // Send SNMP request and handle response
    if (snmp_synch_response(ss, pdu, &response) == STAT_SUCCESS)
    {
        if (response->errstat == SNMP_ERR_NOERROR)
        {
            // Process SNMP response
            for (vars = response->variables; vars; vars = vars->next_variable)
            {
                state[state_count] = *vars->val.integer;
                state_count++;
            }
        }
        else
        {
            fprintf(stderr, "Error in packet.\nReason: %s\n", snmp_errstring(response->errstat));
            rc = SR_ERR_INTERNAL;
        }
    }
    else
    {
        fprintf(stderr, "Error in request.\n");
        rc = SR_ERR_INTERNAL;
    }
    snmp_free_pdu(response);

    pdu = snmp_pdu_create(SNMP_MSG_GETBULK);
    pdu->non_repeaters = 0;
    pdu->max_repetitions = 52;
    name_length = sizeof(enableOid) / sizeof(oid);
    snmp_add_null_var(pdu, enableOid, name_length);

    // Send SNMP request and handle response
    if (snmp_synch_response(ss, pdu, &response) == STAT_SUCCESS)
    {
        if (response->errstat == SNMP_ERR_NOERROR)
        {
            // Process SNMP response
            for (vars = response->variables; vars; vars = vars->next_variable)
            {
                enable[enable_count] = *vars->val.integer;
                enable_count++;
            }
        }
        else
        {
            fprintf(stderr, "Error in packet.\nReason: %s\n", snmp_errstring(response->errstat));
            rc = SR_ERR_INTERNAL;
        }
    }
    else
    {
        fprintf(stderr, "Error in request.\n");
        rc = SR_ERR_INTERNAL;
    }
    snmp_free_pdu(response);

    pdu = snmp_pdu_create(SNMP_MSG_GETBULK);
    pdu->non_repeaters = 0;
    pdu->max_repetitions = 52;
    name_length = sizeof(pathOid) / sizeof(oid);
    snmp_add_null_var(pdu, pathOid, name_length);

    // Send SNMP request and handle response
    if (snmp_synch_response(ss, pdu, &response) == STAT_SUCCESS)
    {
        if (response->errstat == SNMP_ERR_NOERROR)
        {
            // Process SNMP response
            for (vars = response->variables; vars; vars = vars->next_variable)
            {
                path[path_count] = *vars->val.integer;
                path_count++;
            }
        }
        else
        {
            fprintf(stderr, "Error in packet.\nReason: %s\n", snmp_errstring(response->errstat));
            rc = SR_ERR_INTERNAL;
        }
    }
    else
    {
        fprintf(stderr, "Error in request.\n");
        rc = SR_ERR_INTERNAL;
    }
    snmp_free_pdu(response);

    for(int i =0; i < index_count; i++){
        printf("Index : %d, Priority : %d, Port State : %d, Admin Status : %d, Path Cost : %d\n",index[i],priority[i],state[i],enable[i],path[i]);
    }

    if (rc == SR_ERR_OK)
    {
        // Apply changes to sysrepo data tree
        for (size_t i = 0; i < index_count; i++)
        {
            // Set XPath for interface container
            snprintf(xpath, sizeof(xpath), "/stp_interface_get:stp/interface[index='%d']", index[i]);

            // Check if the container exists
            sr_val_t *value;
            rc = sr_get_item(session, xpath, 0, &value);
            if (rc == SR_ERR_NOT_FOUND)
            {
                // Container does not exist, create it
                printf("Container does not exist, creating: %s\n", xpath);
                rc = sr_set_item(session, xpath, NULL, SR_EDIT_DEFAULT);
                if (rc != SR_ERR_OK)
                {
                    fprintf(stderr, "Failed to create interface container: %s\n", sr_strerror(rc));
                    return rc;
                }
                else
                {
                    printf("Interface container created successfully: %s\n", xpath);
                }
            }
            else if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Error checking interface container: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                // Container exists, continue
                printf("Container already exists: %s\n", xpath);
            }
            // priority
            snprintf(xpath, sizeof(xpath), "/stp_interface_get:stp/interface[index='%d']/priority", index[i]);
            sr_val_t priority_val;
            priority_val.type = SR_INT32_T;
            priority_val.data.int32_val = (int32_t)priority[i];
            printf("Setting priority status: %s -> %d\n", xpath, priority[i]);
            rc = sr_set_item(session, xpath, &priority_val, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set priority-status leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("priority status set successfully: %s -> %d\n", xpath, priority[i]);
            }
            // state
            snprintf(xpath, sizeof(xpath), "/stp_interface_get:stp/interface[index='%d']/state", index[i]);
            sr_val_t state_val;
            state_val.type = SR_INT32_T;
            state_val.data.int32_val = (int32_t)state[i];
            printf("Setting state status: %s -> %d\n", xpath, state[i]);
            rc = sr_set_item(session, xpath, &state_val, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set Admin-status leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("state status set successfully: %s -> %d\n", xpath, state[i]);
            }
            // admin_status
            snprintf(xpath, sizeof(xpath), "/stp_interface_get:stp/interface[index='%d']/admin_status", index[i]);
            sr_val_t enable_val;
            enable_val.type = SR_INT32_T;
            enable_val.data.int32_val = (int32_t)enable[i];
            printf("Setting enable status: %s -> %d\n", xpath, enable[i]);
            rc = sr_set_item(session, xpath, &enable_val, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set enable-status leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("Admin status set successfully: %s -> %d\n", xpath, enable[i]);
            }
            // path cost
            snprintf(xpath, sizeof(xpath), "/stp_interface_get:stp/interface[index='%d']/path_cost", index[i]);
            sr_val_t path_val;
            path_val.type = SR_INT32_T;
            path_val.data.int32_val = (int32_t)path[i];
            printf("Setting path status: %s -> %d\n", xpath, path[i]);
            rc = sr_set_item(session, xpath, &path_val, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set path-status leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("Path Cost set successfully: %s -> %d\n", xpath, path[i]);
            }
        }
        rc = sr_apply_changes(session, 0);
        if (rc != SR_ERR_OK)
        {
            fprintf(stderr, "Failed to apply changes to the data tree: %s\n", sr_strerror(rc));
            return rc;
        }
        rc = sr_validate(session, NULL, 0);
        if (rc != SR_ERR_OK)
        {
            fprintf(stderr, "Validation failed: %s\n", sr_strerror(rc));
            return rc;
        }
        else
        {
            printf("Validation succeeded.\n");
        }
        printf("SNMP data successfully set in the data tree.\n");
    }

    return rc;
}

int main(int argc, char **argv)
{
    sr_conn_ctx_t *conn = NULL;
    sr_session_ctx_t *session = NULL;
    int rc = SR_ERR_OK;

    // Connect to sysrepo
    rc = sr_connect(SR_CONN_DEFAULT, &conn);
    if (rc != SR_ERR_OK)
    {
        fprintf(stderr, "Error connecting to sysrepo: %s\n", sr_strerror(rc));
        goto cleanup;
    }

    // Start a session
    rc = sr_session_start(conn, SR_DS_RUNNING, &session);
    if (rc != SR_ERR_OK)
    {
        fprintf(stderr, "Error starting session: %s\n", sr_strerror(rc));
        goto cleanup;
    }

    // Apply data to data tree
    rc = apply_stpg_data_to_data_tree(session);
    if (rc != SR_ERR_OK)
    {
        fprintf(stderr, "Error applying data to data tree: %s\n", sr_strerror(rc));
    }

    rc = apply_stp_data_to_data_tree(session);
    if (rc != SR_ERR_OK)
    {
        fprintf(stderr, "Error applying data to data tree: %s\n", sr_strerror(rc));
    }

cleanup:
    // Cleanup sysrepo session and connection
    if (session)
    {
        sr_session_stop(session);
    }
    if (conn)
    {
        sr_disconnect(conn);
    }

    return rc;
}
