#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <sysrepo.h>
#include <libyang/libyang.h>

#define SNMP_HOST "203.0.113.121"
#define SNMP_COMMUNITY "qnpublic"

// Define SNMP OID for IP addresses
oid ipAddOid[] = {1, 3, 6, 1, 4, 1, 89, 26, 1, 1};
oid poeOid[] = {1, 3, 6, 1, 2, 1, 105, 1, 1, 1};
oid verOid[] = {1, 3, 6, 1, 4, 1, 89, 2, 16, 1, 1};
oid indexOid[] = {1, 3, 6, 1, 2, 1, 17, 2, 15, 1, 1, 0};
oid priorityOid[] = {1, 3, 6, 1, 2, 1, 17, 2, 15, 1, 2, 0};
oid stateOid[] = {1, 3, 6, 1, 2, 1, 17, 2, 15, 1, 3, 0};
oid enableOid[] = {1, 3, 6, 1, 2, 1, 17, 2, 15, 1, 4, 0};
oid pathOid[] = {1, 3, 6, 1, 2, 1, 17, 2, 15, 1, 5, 0};
oid stpgOid[] = {1, 3, 6, 1, 2, 1, 17, 2, 1, 0};
oid iprOid[] = {1, 3, 6, 1, 4, 1, 89, 26, 17, 1, 1};

int apply_ipr_data_to_data_tree(sr_session_ctx_t *session)
{
    netsnmp_session session_snmp, *ss;
    netsnmp_pdu *response, *pdu;
    netsnmp_variable_list *vars;
    int rc = SR_ERR_OK;
    int ipAddress_count = 0, index_count = 0, subnetMask_count = 0, nextHop_count = 0, metric_count = 0;
    char ipAddress[100][255], subnetMask[100][255], nextHop[100][255];
    int index[100], metric[100];
    char xpath[512];

    // Initialize SNMP session
    snmp_sess_init(&session_snmp);
    session_snmp.peername = strdup(SNMP_HOST);
    session_snmp.version = SNMP_VERSION_2c;
    session_snmp.community = (unsigned char *)SNMP_COMMUNITY;
    session_snmp.community_len = strlen(SNMP_COMMUNITY);
    ss = snmp_open(&session_snmp);
    if (!ss)
    {
        snmp_sess_perror("snmpwalk", &session_snmp);
        return SR_ERR_INTERNAL;
    }

    // Prepare SNMP OID for retrieval
    oid name[MAX_OID_LEN];
    size_t name_length;

    memmove(name, iprOid, sizeof(iprOid));
    name_length = sizeof(iprOid) / sizeof(oid);

    // Main SNMP retrieval loop
    while (1)
    {
        pdu = snmp_pdu_create(SNMP_MSG_GETNEXT);
        snmp_add_null_var(pdu, name, name_length);

        // Send SNMP request and handle response
        if (snmp_synch_response(ss, pdu, &response) == STAT_SUCCESS)
        {
            if (response->errstat == SNMP_ERR_NOERROR)
            {
                // Process SNMP response
                for (vars = response->variables; vars; vars = vars->next_variable)
                {
                    if (vars->type == ASN_IPADDRESS)
                    {
                        switch (vars->name[11])
                        {
                        case 1:
                            char ip_str[INET_ADDRSTRLEN];
                            inet_ntop(AF_INET, vars->val.string, ip_str, INET_ADDRSTRLEN);

                            strncpy(ipAddress[ipAddress_count], ip_str, INET_ADDRSTRLEN - 1);
                            ipAddress[ipAddress_count][INET_ADDRSTRLEN - 1] = '\0'; // Ensure null termination

                            ipAddress_count++;
                            break;
                        case 2:
                            char ip_str2[INET_ADDRSTRLEN];
                            inet_ntop(AF_INET, vars->val.string, ip_str, INET_ADDRSTRLEN);

                            strncpy(subnetMask[subnetMask_count], ip_str, INET_ADDRSTRLEN - 1);
                            subnetMask[subnetMask_count][INET_ADDRSTRLEN - 1] = '\0'; // Ensure null termination

                            subnetMask_count++;
                            break;
                        case 4:
                            char ip_str3[INET_ADDRSTRLEN];
                            inet_ntop(AF_INET, vars->val.string, ip_str, INET_ADDRSTRLEN);

                            strncpy(nextHop[nextHop_count], ip_str, INET_ADDRSTRLEN - 1);
                            nextHop[nextHop_count][INET_ADDRSTRLEN - 1] = '\0'; // Ensure null termination

                            nextHop_count++;
                        }
                    }
                    if(vars->type == ASN_INTEGER && vars->name[11] == 5){
                        metric[metric_count++] = *vars->val.integer;
                    }

                    memmove(name, vars->name, vars->name_length * sizeof(oid));
                    name_length = vars->name_length;

                    // Exit loop on specific OID condition
                    if (vars->name[10] == 6)
                        goto end_of_loop;
                }
            }
            else
            {
                fprintf(stderr, "Error in packet.\nReason: %s\n", snmp_errstring(response->errstat));
                rc = SR_ERR_INTERNAL;
                break;
            }
        }
        else
        {
            fprintf(stderr, "Error in request.\n");
            rc = SR_ERR_INTERNAL;
            break;
        }
        snmp_free_pdu(response);
    }

end_of_loop:
    snmp_close(ss);

    for (int i = 0; i < ipAddress_count; i++)
    {
        index[i] = i + 1;
        index_count++;
    }

    // Handle SNMP data processing
    if (rc == SR_ERR_OK)
    {
        // Apply changes to sysrepo data tree
        for (size_t i = 0; i < index_count; i++)
        {
            // Set XPath for interface container
            snprintf(xpath, sizeof(xpath), "/ip_route_get:ip_route/routes[index='%d']", index[i]);

            // Check if the container exists
            sr_val_t *value;
            rc = sr_get_item(session, xpath, 0, &value);
            if (rc == SR_ERR_NOT_FOUND)
            {
                // Container does not exist, create it
                printf("Container does not exist, creating: %s\n", xpath);
                rc = sr_set_item(session, xpath, NULL, SR_EDIT_DEFAULT);
                if (rc != SR_ERR_OK)
                {
                    fprintf(stderr, "Failed to create interface container: %s\n", sr_strerror(rc));
                    return rc;
                }
                else
                {
                    printf("Interface container created successfully: %s\n", xpath);
                }
            }
            else if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Error checking interface container: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                // Container exists, continue
                printf("Container already exists: %s\n", xpath);
            }
            // powered-device-description
            if (ipAddress[i][0] != '\0')
            {
                snprintf(xpath, sizeof(xpath), "/ip_route_get:ip_route/routes[index='%d']/ipAddress", index[i]);
                sr_val_t ipAddress_val;
                ipAddress_val.type = SR_STRING_T;
                ipAddress_val.data.string_val = ipAddress[i];
                printf("Setting Ip Address: %s -> %s\n", xpath, ipAddress[i]);
                rc = sr_set_item(session, xpath, &ipAddress_val, SR_EDIT_DEFAULT);
                if (rc != SR_ERR_OK)
                {
                    fprintf(stderr, "Failed to set ipAddress leaf: %s\n", sr_strerror(rc));
                    return rc;
                }
                else
                {
                    printf("Ip Address set successfully: %s -> %s\n", xpath, ipAddress[i]);
                }
            }
            if (subnetMask[i][0] != '\0')
            {
                snprintf(xpath, sizeof(xpath), "/ip_route_get:ip_route/routes[index='%d']/subnetMask", index[i]);
                sr_val_t subnetMask_val;
                subnetMask_val.type = SR_STRING_T;
                subnetMask_val.data.string_val = subnetMask[i];
                printf("Setting Subnet Mask: %s -> %s\n", xpath, subnetMask[i]);
                rc = sr_set_item(session, xpath, &subnetMask_val, SR_EDIT_DEFAULT);
                if (rc != SR_ERR_OK)
                {
                    fprintf(stderr, "Failed to set Subnet Mask leaf: %s\n", sr_strerror(rc));
                    return rc;
                }
                else
                {
                    printf("Subnet Mask set successfully: %s -> %s\n", xpath, subnetMask[i]);
                }
            }
            if (nextHop[i][0] != '\0')
            {
                snprintf(xpath, sizeof(xpath), "/ip_route_get:ip_route/routes[index='%d']/nextHop", index[i]);
                sr_val_t nextHop_val;
                nextHop_val.type = SR_STRING_T;
                nextHop_val.data.string_val = nextHop[i];
                printf("Setting Next Hop: %s -> %s\n", xpath, nextHop[i]);
                rc = sr_set_item(session, xpath, &nextHop_val, SR_EDIT_DEFAULT);
                if (rc != SR_ERR_OK)
                {
                    fprintf(stderr, "Failed to set Next Hop leaf: %s\n", sr_strerror(rc));
                    return rc;
                }
                else
                {
                    printf("Next Hop set successfully: %s -> %s\n", xpath, nextHop[i]);
                }
            }
            snprintf(xpath, sizeof(xpath), "/ip_route_get:ip_route/routes[index='%d']/metric", index[i]);
            sr_val_t metric_val;
            metric_val.type = SR_INT32_T;
            metric_val.data.int32_val = (int32_t) metric[i];
            printf("Setting metric: %s -> %d\n", xpath, metric[i]);
            rc = sr_set_item(session, xpath, &metric_val, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set metric leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("Metric set successfully: %s -> %d\n", xpath, metric[i]);
            }
        }
        rc = sr_apply_changes(session, 0);
        if (rc != SR_ERR_OK)
        {
            fprintf(stderr, "Failed to apply changes to the data tree: %s\n", sr_strerror(rc));
            return rc;
        }
        rc = sr_validate(session, NULL, 0);
        if (rc != SR_ERR_OK)
        {
            fprintf(stderr, "Validation failed: %s\n", sr_strerror(rc));
            return rc;
        }
        else
        {
            printf("Validation succeeded.\n");
        }
        printf("SNMP data successfully set in the data tree.\n");
    }

    return rc;
}

int apply_ip_data_to_data_tree(sr_session_ctx_t *session)
{
    netsnmp_session session_snmp, *ss;
    netsnmp_pdu *response, *pdu;
    netsnmp_variable_list *vars;
    int rc = SR_ERR_OK;
    int ip_address_count = 0, index_count = 0, admin_st_count = 0, oper_st_count = 0, subnet_mask_count=0, owner_count=0;
    char ip_address[100][INET_ADDRSTRLEN], subnet_mask[100][INET_ADDRSTRLEN];
    int index[100], admin_st[100], oper_st[100], owner[100];
    char xpath[512];

    // Initialize SNMP session
    snmp_sess_init(&session_snmp);
    session_snmp.peername = strdup(SNMP_HOST);
    session_snmp.version = SNMP_VERSION_2c;
    session_snmp.community = (unsigned char *)SNMP_COMMUNITY;
    session_snmp.community_len = strlen(SNMP_COMMUNITY);
    ss = snmp_open(&session_snmp);
    if (!ss)
    {
        snmp_sess_perror("snmpwalk", &session_snmp);
        return SR_ERR_INTERNAL;
    }

    // Prepare SNMP OID for retrieval
    oid name[MAX_OID_LEN];
    size_t name_length;

    memmove(name, ipAddOid, sizeof(ipAddOid));
    name_length = sizeof(ipAddOid) / sizeof(oid);

    // Main SNMP retrieval loop
    while (1)
    {
        pdu = snmp_pdu_create(SNMP_MSG_GETNEXT);
        snmp_add_null_var(pdu, name, name_length);

        // Send SNMP request and handle response
        if (snmp_synch_response(ss, pdu, &response) == STAT_SUCCESS)
        {
            if (response->errstat == SNMP_ERR_NOERROR)
            {
                // Process SNMP response
                for (vars = response->variables; vars; vars = vars->next_variable)
                {
                    if (vars->type == ASN_IPADDRESS && vars->name[10] == 1)
                    {
                        char ip_str[INET_ADDRSTRLEN];
                        inet_ntop(AF_INET, vars->val.string, ip_str, INET_ADDRSTRLEN);
                        strncpy(ip_address[ip_address_count], ip_str, INET_ADDRSTRLEN - 1);
                        ip_address[ip_address_count][INET_ADDRSTRLEN - 1] = '\0';
                        ip_address_count++;
                    }
                    else if (vars->type == ASN_IPADDRESS && vars->name[10] == 3)
                    {
                        char ip_str[INET_ADDRSTRLEN];
                        inet_ntop(AF_INET, vars->val.string, ip_str, INET_ADDRSTRLEN);
                        strncpy(subnet_mask[subnet_mask_count], ip_str, INET_ADDRSTRLEN - 1);
                        subnet_mask[subnet_mask_count][INET_ADDRSTRLEN - 1] = '\0';
                        subnet_mask_count++;
                    }
                    else if (vars->type == ASN_INTEGER)
                    {
                        int data_value = *vars->val.integer;
                        switch (vars->name[10])
                        {
                        case 2:
                            index[index_count++] = data_value;
                            break;
                        case 10:
                            owner[owner_count++] = data_value;
                        case 11:
                            admin_st[admin_st_count++] = data_value;
                            break;
                        case 12:
                            oper_st[oper_st_count++] = data_value;
                            break;
                        }
                    }

                    // Update OID for next SNMP request
                    memmove(name, vars->name, vars->name_length * sizeof(oid));
                    name_length = vars->name_length;

                    // Exit loop on specific OID condition
                    if (vars->name[10] == 13)
                        goto end_of_loop;
                }
            }
            else
            {
                fprintf(stderr, "Error in packet.\nReason: %s\n", snmp_errstring(response->errstat));
                rc = SR_ERR_INTERNAL;
                break;
            }
        }
        else
        {
            fprintf(stderr, "Error in request.\n");
            rc = SR_ERR_INTERNAL;
            break;
        }
        snmp_free_pdu(response);
    }

end_of_loop:
    snmp_close(ss);

    // Handle SNMP data processing
    if (rc == SR_ERR_OK)
    {
        // Apply changes to sysrepo data tree
        for (size_t i = 0; i < index_count; i++)
        {
            // Set XPath for interface container
            snprintf(xpath, sizeof(xpath), "/ipInterfaces:ipData/interface[index='%d']", index[i]);

            // Check if the container exists
            sr_val_t *value;
            rc = sr_get_item(session, xpath, 0, &value);
            if (rc == SR_ERR_NOT_FOUND)
            {
                // Container does not exist, create it
                printf("Container does not exist, creating: %s\n", xpath);
                rc = sr_set_item(session, xpath, NULL, SR_EDIT_DEFAULT);
                if (rc != SR_ERR_OK)
                {
                    fprintf(stderr, "Failed to create interface container: %s\n", sr_strerror(rc));
                    return rc;
                }
                else
                {
                    printf("Interface container created successfully: %s\n", xpath);
                }
            }
            else if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Error checking interface container: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                // Container exists, continue
                printf("Container already exists: %s\n", xpath);
            }

            // Set XPath for IP address leaf
            snprintf(xpath, sizeof(xpath), "/ipInterfaces:ipData/interface[index='%d']/ipAddress", index[i]);
            printf("Setting IP address: %s -> %s\n", xpath, ip_address[i]);
            rc = sr_set_item_str(session, xpath, ip_address[i], NULL, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set ip-address leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("IP address set successfully: %s -> %s\n", xpath, ip_address[i]);
            }

            snprintf(xpath, sizeof(xpath), "/ipInterfaces:ipData/interface[index='%d']/subnetMask", index[i]);
            printf("Setting Subnet Mask: %s -> %s\n", xpath, subnet_mask[i]);
            rc = sr_set_item_str(session, xpath, subnet_mask[i], NULL, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set ip-address leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("Subnet Mask set successfully: %s -> %s\n", xpath, subnet_mask[i]);
            }

            snprintf(xpath, sizeof(xpath), "/ipInterfaces:ipData/interface[index='%d']/owner", index[i]);
            sr_val_t owner_val;
            owner_val.type = SR_INT32_T;
            owner_val.data.int32_val = (int32_t)owner[i];
            printf("Setting admin status: %s -> %d\n", xpath, owner[i]);
            rc = sr_set_item(session, xpath, &owner_val, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set admin-status leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("Owner set successfully: %s -> %d\n", xpath, owner[i]);
            }

            // Set XPath for admin status leaf
            snprintf(xpath, sizeof(xpath), "/ipInterfaces:ipData/interface[index='%d']/adminStatus", index[i]);
            sr_val_t admin_val;
            admin_val.type = SR_INT32_T;
            admin_val.data.int32_val = (int32_t)admin_st[i];
            printf("Setting admin status: %s -> %d\n", xpath, admin_st[i]);
            rc = sr_set_item(session, xpath, &admin_val, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set admin-status leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("Admin status set successfully: %s -> %d\n", xpath, admin_st[i]);
            }

            // Set XPath for operational status leaf
            snprintf(xpath, sizeof(xpath), "/ipInterfaces:ipData/interface[index='%d']/operStatus", index[i]);
            sr_val_t oper_val;
            oper_val.type = SR_INT32_T;
            oper_val.data.int32_val = (int32_t)oper_st[i];
            printf("Setting operational status: %s -> %d\n", xpath, oper_st[i]);
            rc = sr_set_item(session, xpath, &oper_val, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set oper-status leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("Operational status set successfully: %s -> %d\n", xpath, oper_st[i]);
            }
        }

        // Apply changes to the data tree
        rc = sr_apply_changes(session, 0);
        if (rc != SR_ERR_OK)
        {
            fprintf(stderr, "Failed to apply changes to the data tree: %s\n", sr_strerror(rc));
            return rc;
        }

        // Validate the data tree
        rc = sr_validate(session, NULL, 0);
        if (rc != SR_ERR_OK)
        {
            fprintf(stderr, "Validation failed: %s\n", sr_strerror(rc));
            return rc;
        }
        else
        {
            printf("Validation succeeded.\n");
        }

        printf("SNMP data successfully set in the data tree.\n");
    }

    return rc;
}



int apply_poe_data_to_data_tree(sr_session_ctx_t *session)
{
    netsnmp_session session_snmp, *ss;
    netsnmp_pdu *response, *pdu;
    netsnmp_variable_list *vars;
    int rc = SR_ERR_OK;
    int description_count = 0, index_count = 0, priority_count = 0, admin_st_count = 0, oper_st_count = 0, power_count = 0, class_count = 0;
    char description[100][255];
    int index[100], admin_st[100], oper_st[100], power[100], class[100], priority[100];
    char xpath[512];

    // Initialize SNMP session
    snmp_sess_init(&session_snmp);
    session_snmp.peername = strdup(SNMP_HOST);
    session_snmp.version = SNMP_VERSION_2c;
    session_snmp.community = (unsigned char *)SNMP_COMMUNITY;
    session_snmp.community_len = strlen(SNMP_COMMUNITY);
    ss = snmp_open(&session_snmp);
    if (!ss)
    {
        snmp_sess_perror("snmpwalk", &session_snmp);
        return SR_ERR_INTERNAL;
    }

    // Prepare SNMP OID for retrieval
    oid name[MAX_OID_LEN];
    size_t name_length;

    memmove(name, poeOid, sizeof(poeOid));
    name_length = sizeof(poeOid) / sizeof(oid);

    // Main SNMP retrieval loop
    while (1)
    {
        pdu = snmp_pdu_create(SNMP_MSG_GETNEXT);
        snmp_add_null_var(pdu, name, name_length);

        // Send SNMP request and handle response
        if (snmp_synch_response(ss, pdu, &response) == STAT_SUCCESS)
        {
            if (response->errstat == SNMP_ERR_NOERROR)
            {
                // Process SNMP response
                for (vars = response->variables; vars; vars = vars->next_variable)
                {
                    if (vars->type == ASN_INTEGER)
                    {
                        int data_value = *vars->val.integer;
                        switch (vars->name[10])
                        {
                        case 3:
                            admin_st[admin_st_count++] = data_value;
                            printf("Admin status: %d\n", data_value);
                            break;
                        case 6:
                            oper_st[oper_st_count++] = data_value;
                            printf("Operational status: %d\n", data_value);
                            break;
                        case 7:
                            priority[priority_count++] = data_value;
                            printf("Priority: %d\n", data_value);
                            break;
                        case 10:
                            class[class_count++] = data_value;
                            printf("Class: %d\n", data_value);
                            break;
                        case 15:
                            power[power_count++] = data_value;
                            printf("Power: %d\n", data_value);
                            break;
                        }
                    }
                    else if (vars->type == ASN_OCTET_STR && vars->name[10] == 9)
                    {
                        snprintf(description[description_count], sizeof(description[description_count]), "%s", vars->val.string);
                        printf("Description: %s\n", vars->val.string);
                        description_count++;
                    }

                    // Update OID for next SNMP request
                    memmove(name, vars->name, vars->name_length * sizeof(oid));
                    name_length = vars->name_length;

                    // Exit loop on specific OID condition
                    if (vars->name[10] == 16)
                        goto end_of_loop;
                }
            }
            else
            {
                fprintf(stderr, "Error in packet.\nReason: %s\n", snmp_errstring(response->errstat));
                rc = SR_ERR_INTERNAL;
                break;
            }
        }
        else
        {
            fprintf(stderr, "Error in request.\n");
            rc = SR_ERR_INTERNAL;
            break;
        }
        snmp_free_pdu(response);
    }

end_of_loop:
    snmp_close(ss);

    for (int i = 0; i < admin_st_count; i++)
    {
        index[i] = i + 1;
        index_count++;
    }

    // Handle SNMP data processing
    if (rc == SR_ERR_OK)
    {
        // Apply changes to sysrepo data tree
        for (size_t i = 0; i < index_count; i++)
        {
            // Set XPath for interface container
            snprintf(xpath, sizeof(xpath), "/poe_get:poe-get/interface[index='%d']", index[i]);

            // Check if the container exists
            sr_val_t *value;
            rc = sr_get_item(session, xpath, 0, &value);
            if (rc == SR_ERR_NOT_FOUND)
            {
                // Container does not exist, create it
                printf("Container does not exist, creating: %s\n", xpath);
                rc = sr_set_item(session, xpath, NULL, SR_EDIT_DEFAULT);
                if (rc != SR_ERR_OK)
                {
                    fprintf(stderr, "Failed to create interface container: %s\n", sr_strerror(rc));
                    return rc;
                }
                else
                {
                    printf("Interface container created successfully: %s\n", xpath);
                }
            }
            else if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Error checking interface container: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                // Container exists, continue
                printf("Container already exists: %s\n", xpath);
            }

            // admin_st
            snprintf(xpath, sizeof(xpath), "/poe_get:poe-get/interface[index='%d']/admin_st", index[i]);
            sr_val_t admin_val;
            admin_val.type = SR_INT32_T;
            admin_val.data.int32_val = (int32_t)admin_st[i];
            printf("Setting admin status: %s -> %d\n", xpath, admin_st[i]);
            rc = sr_set_item(session, xpath, &admin_val, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set admin-status leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("Admin status set successfully: %s -> %d\n", xpath, admin_st[i]);
            }

            // oper_st
            snprintf(xpath, sizeof(xpath), "/poe_get:poe-get/interface[index='%d']/oper_st", index[i]);
            sr_val_t oper_val;
            oper_val.type = SR_INT32_T;
            oper_val.data.int32_val = (int32_t)oper_st[i];
            printf("Setting operational status: %s -> %d\n", xpath, oper_st[i]);
            rc = sr_set_item(session, xpath, &oper_val, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set oper-status leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("Operational status set successfully: %s -> %d\n", xpath, oper_st[i]);
            }

            // power
            snprintf(xpath, sizeof(xpath), "/poe_get:poe-get/interface[index='%d']/power", index[i]);
            sr_val_t power_val;
            power_val.type = SR_INT32_T;
            power_val.data.int32_val = (int32_t)power[i];
            printf("Setting power: %s -> %d\n", xpath, power[i]);
            rc = sr_set_item(session, xpath, &power_val, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set power leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("Power set successfully: %s -> %d\n", xpath, power[i]);
            }

            // priority
            snprintf(xpath, sizeof(xpath), "/poe_get:poe-get/interface[index='%d']/priority", index[i]);
            sr_val_t priority_val;
            priority_val.type = SR_INT32_T;
            priority_val.data.int32_val = (int32_t)priority[i];
            printf("Setting priority: %s -> %d\n", xpath, priority[i]);
            rc = sr_set_item(session, xpath, &priority_val, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set priority leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("Priority set successfully: %s -> %d\n", xpath, priority[i]);
            }

            // powered-device-description
            if (description[i][0] != '\0')
            {
                snprintf(xpath, sizeof(xpath), "/poe_get:poe-get/interface[index='%d']/powered-device-description", index[i]);
                sr_val_t desc_val;
                desc_val.type = SR_STRING_T;
                desc_val.data.string_val = description[i];
                printf("Setting description: %s -> %s\n", xpath, description[i]);
                rc = sr_set_item(session, xpath, &desc_val, SR_EDIT_DEFAULT);
                if (rc != SR_ERR_OK)
                {
                    fprintf(stderr, "Failed to set description leaf: %s\n", sr_strerror(rc));
                    return rc;
                }
                else
                {
                    printf("Description set successfully: %s -> %s\n", xpath, description[i]);
                }
            }
            snprintf(xpath, sizeof(xpath), "/poe_get:poe-get/interface[index='%d']/class", index[i]);
            sr_val_t class_val;
            class_val.type = SR_INT32_T;
            class_val.data.int32_val = (int32_t) class[i];
            printf("Setting class: %s -> %d\n", xpath, class[i]);
            rc = sr_set_item(session, xpath, &class_val, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set class leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("class set successfully: %s -> %d\n", xpath, class[i]);
            }
        }
        rc = sr_apply_changes(session, 0);
        if (rc != SR_ERR_OK)
        {
            fprintf(stderr, "Failed to apply changes to the data tree: %s\n", sr_strerror(rc));
            return rc;
        }
        rc = sr_validate(session, NULL, 0);
        if (rc != SR_ERR_OK)
        {
            fprintf(stderr, "Validation failed: %s\n", sr_strerror(rc));
            return rc;
        }
        else
        {
            printf("Validation succeeded.\n");
        }
        printf("SNMP data successfully set in the data tree.\n");
    }

    return rc;
}



int apply_ver_data_to_data_tree(sr_session_ctx_t *session)
{
    netsnmp_session session_snmp, *ss;
    netsnmp_pdu *response, *pdu;
    netsnmp_variable_list *vars;
    int rc = SR_ERR_OK;
    int img_name_count = 0, img_ver_count = 0, img_date_count = 0, img_time_count = 0, index[100], index_count = 0;
    char img_name[100][255], img_ver[100][255], img_date[100][255], img_time[100][255];
    char xpath[512];

    // Initialize SNMP session
    snmp_sess_init(&session_snmp);
    session_snmp.peername = strdup(SNMP_HOST);
    session_snmp.version = SNMP_VERSION_2c;
    session_snmp.community = (unsigned char *)SNMP_COMMUNITY;
    session_snmp.community_len = strlen(SNMP_COMMUNITY);
    ss = snmp_open(&session_snmp);
    if (!ss)
    {
        snmp_sess_perror("snmpwalk", &session_snmp);
        return SR_ERR_INTERNAL;
    }

    // Prepare SNMP OID for retrieval
    oid name[MAX_OID_LEN];
    size_t name_length;

    memmove(name, verOid, sizeof(verOid));
    name_length = sizeof(verOid) / sizeof(oid);

    // Main SNMP retrieval loop
    while (1)
    {
        pdu = snmp_pdu_create(SNMP_MSG_GETNEXT);
        snmp_add_null_var(pdu, name, name_length);

        // Send SNMP request and handle response
        if (snmp_synch_response(ss, pdu, &response) == STAT_SUCCESS)
        {
            if (response->errstat == SNMP_ERR_NOERROR)
            {
                // Process SNMP response
                for (vars = response->variables; vars; vars = vars->next_variable)
                {
                    char buf[1024];
                    size_t buf_len = sizeof(buf);
                    snprint_objid(buf, buf_len, vars->name, vars->name_length);
                    printf("OID: %s\n", buf);
                    if (vars->type == ASN_OCTET_STR && vars->name[11] == 2 || vars->name[11] == 3)
                    {
                        snprintf(img_name[img_name_count], sizeof(img_name[img_name_count]), "%s", vars->val.string);
                        img_name_count++;
                    }
                    if (vars->type == ASN_OCTET_STR && vars->name[11] == 4 || vars->name[11] == 5)
                    {
                        snprintf(img_ver[img_ver_count], sizeof(img_ver[img_ver_count]), "%s", vars->val.string);
                        img_ver_count++;
                    }
                    if (vars->type == ASN_OCTET_STR && vars->name[11] == 6 || vars->name[11] == 7)
                    {
                        snprintf(img_date[img_date_count], sizeof(img_date[img_date_count]), "%s", vars->val.string);
                        img_date_count++;
                    }
                    if (vars->type == ASN_OCTET_STR && vars->name[11] == 8 || vars->name[11] == 9)
                    {
                        snprintf(img_time[img_time_count], sizeof(img_time[img_time_count]), "%s", vars->val.string);
                        img_time_count++;
                    }
                    // Update OID for next SNMP request
                    memmove(name, vars->name, vars->name_length * sizeof(oid));
                    name_length = vars->name_length;

                    // Exit loop on specific OID condition
                    if (vars->name[11] == 10)
                        goto end_of_loop;
                }
            }
            else
            {
                fprintf(stderr, "Error in packet.\nReason: %s\n", snmp_errstring(response->errstat));
                rc = SR_ERR_INTERNAL;
                break;
            }
        }
        else
        {
            fprintf(stderr, "Error in request.\n");
            rc = SR_ERR_INTERNAL;
            break;
        }
        snmp_free_pdu(response);
    }

end_of_loop:
    snmp_close(ss);

    for (int i = 0; i < img_name_count; i++)
    {
        index[i] = i + 1;
        index_count++;
    }
    // Handle SNMP data processing
    if (rc == SR_ERR_OK)
    {
        // Apply changes to sysrepo data tree
        for (size_t i = 0; i < index_count; i++)
        {
            // Set XPath for interface container
            snprintf(xpath, sizeof(xpath), "/sh_version:version/system_version[index='%d']", index[i]);

            // Check if the container exists
            sr_val_t *value;
            rc = sr_get_item(session, xpath, 0, &value);
            if (rc == SR_ERR_NOT_FOUND)
            {
                // Container does not exist, create it
                printf("Container does not exist, creating: %s\n", xpath);
                rc = sr_set_item(session, xpath, NULL, SR_EDIT_DEFAULT);
                if (rc != SR_ERR_OK)
                {
                    fprintf(stderr, "Failed to create interface container: %s\n", sr_strerror(rc));
                    return rc;
                }
                else
                {
                    printf("Interface container created successfully: %s\n", xpath);
                }
            }
            else if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Error checking interface container: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                // Container exists, continue
                printf("Container already exists: %s\n", xpath);
            }

            // image name
            snprintf(xpath, sizeof(xpath), "/sh_version:version/system_version[index='%d']/image_name", index[i]);
            sr_val_t img_name_val;
            img_name_val.type = SR_STRING_T;
            img_name_val.data.string_val = img_name[i];
            printf("Setting description: %s -> %s\n", xpath, img_name[i]);
            rc = sr_set_item(session, xpath, &img_name_val, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set description leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("Image Name set successfully: %s -> %s\n", xpath, img_name[i]);
            }
            // image version
            snprintf(xpath, sizeof(xpath), "/sh_version:version/system_version[index='%d']/image_version", index[i]);
            sr_val_t img_ver_val;
            img_ver_val.type = SR_STRING_T;
            img_ver_val.data.string_val = img_ver[i];
            printf("Setting description: %s -> %s\n", xpath, img_ver[i]);
            rc = sr_set_item(session, xpath, &img_ver_val, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set description leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("Image Name set successfully: %s -> %s\n", xpath, img_ver[i]);
            }
            // image date
            snprintf(xpath, sizeof(xpath), "/sh_version:version/system_version[index='%d']/image_date", index[i]);
            sr_val_t img_date_val;
            img_date_val.type = SR_STRING_T;
            img_date_val.data.string_val = img_date[i];
            printf("Setting description: %s -> %s\n", xpath, img_date[i]);
            rc = sr_set_item(session, xpath, &img_date_val, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set description leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("Image Name set successfully: %s -> %s\n", xpath, img_date[i]);
            }
            snprintf(xpath, sizeof(xpath), "/sh_version:version/system_version[index='%d']/image_time", index[i]);
            sr_val_t img_time_val;
            img_time_val.type = SR_STRING_T;
            img_time_val.data.string_val = img_time[i];
            printf("Setting description: %s -> %s\n", xpath, img_time[i]);
            rc = sr_set_item(session, xpath, &img_time_val, SR_EDIT_DEFAULT);
            if (rc != SR_ERR_OK)
            {
                fprintf(stderr, "Failed to set description leaf: %s\n", sr_strerror(rc));
                return rc;
            }
            else
            {
                printf("Image Name set successfully: %s -> %s\n", xpath, img_time[i]);
            }
        }
        rc = sr_apply_changes(session, 0);
        if (rc != SR_ERR_OK)
        {
            fprintf(stderr, "Failed to apply changes to the data tree: %s\n", sr_strerror(rc));
            return rc;
        }
        rc = sr_validate(session, NULL, 0);
        if (rc != SR_ERR_OK)
        {
            fprintf(stderr, "Validation failed: %s\n", sr_strerror(rc));
            return rc;
        }
        else
        {
            printf("Validation succeeded.\n");
        }
        printf("SNMP data successfully set in the data tree.\n");
    }

    return rc;
}
int main()
{
    sr_conn_ctx_t *conn = NULL;
    sr_session_ctx_t *session = NULL;
    int rc = SR_ERR_OK;

    // Connect to sysrepo
    rc = sr_connect(SR_CONN_DEFAULT, &conn);
    if (rc != SR_ERR_OK)
    {
        fprintf(stderr, "Error by sr_connect: %s\n", sr_strerror(rc));
        return rc;
    }

    // Start session
    rc = sr_session_start(conn, SR_DS_RUNNING, &session);
    if (rc != SR_ERR_OK)
    {
        fprintf(stderr, "Error by sr_session_start: %s\n", sr_strerror(rc));
        sr_disconnect(conn);
        return rc;
    }

    // Apply SNMP data to sysrepo data tree
    rc = apply_ip_data_to_data_tree(session);
    if (rc != SR_ERR_OK)
    {
        fprintf(stderr, "Error by apply_ipdata_to_data_tree: %s\n", sr_strerror(rc));
    }

    rc = apply_poe_data_to_data_tree(session);
    if (rc != SR_ERR_OK)
    {
        fprintf(stderr, "Error by apply_poedata_to_data_tree: %s\n", sr_strerror(rc));
    }

    rc = apply_ver_data_to_data_tree(session);
    if (rc != SR_ERR_OK)
    {
        fprintf(stderr, "Error by apply_poedata_to_data_tree: %s\n", sr_strerror(rc));
    }

    rc = apply_ipr_data_to_data_tree(session);
    if (rc != SR_ERR_OK)
    {
        fprintf(stderr, "Error by apply_poedata_to_data_tree: %s\n", sr_strerror(rc));
    }

    // Stop session and disconnect from sysrepo
    sr_session_stop(session);
    sr_disconnect(conn);

    return rc;
}