#include <sysrepo.h>
#include <sysrepo/xpath.h>
#include <libyang/libyang.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <stdbool.h>
#include <inttypes.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/types.h>
#include <fcntl.h>
#include <signal.h>

#define MIYAGI_SOCK_PATH "/var/run/roscmd.sock"
#define TIMEOUT_SEC 2

static void route_ip(const char *ip_address, const char *subnet_mask, const char *gateway)
{
  int sock;
  struct sockaddr_un addr;
  char cmd[256];

  sock = socket(AF_UNIX, SOCK_STREAM, 0);
  if (sock < 0)
  {
    perror("socket");
    fprintf(stderr, "Failed to create socket\n");
    return;
  }

  memset(&addr, 0, sizeof(struct sockaddr_un));
  addr.sun_family = AF_UNIX;
  strncpy(addr.sun_path, MIYAGI_SOCK_PATH, sizeof(addr.sun_path) - 1);

  if (connect(sock, (struct sockaddr *)&addr, sizeof(struct sockaddr_un)) < 0)
  {
    perror("connect");
    fprintf(stderr, "Failed to connect to %s\n", MIYAGI_SOCK_PATH);
    close(sock);
    return;
  }

  if (write(sock, "quantum\n", strlen("quantum\n")) < 0)
  {
    perror("write");
    close(sock);
    return;
  }
  if (write(sock, "yToSJATiy1bz\n", strlen("yToSJATiy1bz\n")) < 0)
  {
    perror("write");
    close(sock);
    return;
  }
  if (write(sock, "configure\n", strlen("configure\n")) < 0)
  {
    perror("write");
    close(sock);
    return;
  }
  usleep(500000); // sleep for 0.5 seconds
  snprintf(cmd, sizeof(cmd), "ip route %s %s %s\n", ip_address, subnet_mask, gateway);
  if (write(sock, cmd, strlen(cmd)) < 0)
  {
    perror("write");
    close(sock);
    return;
  }
  printf("Message sent: %s\n", cmd);
  close(sock);
}

static void interface_ip(const char *interface_name, const char *ip_address, const char *subnet_mask)
{
  int sock;
  struct sockaddr_un addr;
  char cmd[256];

  sock = socket(AF_UNIX, SOCK_STREAM, 0);
  if (sock < 0)
  {
    perror("socket");
    fprintf(stderr, "Failed to create socket\n");
    return;
  }

  memset(&addr, 0, sizeof(struct sockaddr_un));
  addr.sun_family = AF_UNIX;
  strncpy(addr.sun_path, MIYAGI_SOCK_PATH, sizeof(addr.sun_path) - 1);

  if (connect(sock, (struct sockaddr *)&addr, sizeof(struct sockaddr_un)) < 0)
  {
    perror("connect");
    fprintf(stderr, "Failed to connect to %s\n", MIYAGI_SOCK_PATH);
    close(sock);
    return;
  }

  if (write(sock, "quantum\n", strlen("quantum\n")) < 0)
  {
    perror("write");
    close(sock);
    return;
  }
  if (write(sock, "yToSJATiy1bz\n", strlen("yToSJATiy1bz\n")) < 0)
  {
    perror("write");
    close(sock);
    return;
  }
  if (write(sock, "configure\n", strlen("configure\n")) < 0)
  {
    perror("write");
    close(sock);
    return;
  }
  sleep(0.5);
  snprintf(cmd, sizeof(cmd), "int %s\n", interface_name);
  if (write(sock, cmd, strlen(cmd)) < 0)
  {
    perror("write");
    close(sock);
    return;
  }
  sleep(0.5);
  snprintf(cmd, sizeof(cmd), "ip address %s %s\n", ip_address, subnet_mask);
  if (write(sock, cmd, strlen(cmd)) < 0)
  {
    perror("write");
    close(sock);
    return;
  }
  printf("Message sent: %s\n", cmd);
  close(sock);
}
static void poe_classMode(const char *class_mode)
{
  int sock;
  struct sockaddr_un addr;
  char cmd[256];

  sock = socket(AF_UNIX, SOCK_STREAM, 0);
  if (sock < 0)
  {
    perror("socket");
    fprintf(stderr, "Failed to create socket\n");
    return;
  }

  memset(&addr, 0, sizeof(struct sockaddr_un));
  addr.sun_family = AF_UNIX;
  strncpy(addr.sun_path, MIYAGI_SOCK_PATH, sizeof(addr.sun_path) - 1);

  if (connect(sock, (struct sockaddr *)&addr, sizeof(struct sockaddr_un)) < 0)
  {
    perror("connect");
    fprintf(stderr, "Failed to connect to %s\n", MIYAGI_SOCK_PATH);
    close(sock);
    return;
  }

  write(sock, "quantum\n", strlen("quantum\n"));
  write(sock, "yToSJATiy1bz\n", strlen("yToSJATiy1bz\n"));
  sleep(0.5);
  write(sock, "configure\n", strlen("configure\n"));
  snprintf(cmd, sizeof(cmd), "power inline limit-mode %s\n", class_mode);
  write(sock, cmd, strlen(cmd));
  printf("Message sent: %s\n", cmd);
  sleep(0.5);
  write(sock, "Y\n", strlen("Y\n"));
  close(sock);
}
// Function to send message to Miyagi agent via Unix domain socket for POE configuration
static void poe_details(const char *interface_name, const char *power_device_description, int limit, const char *priority)
{
  int sock;
  struct sockaddr_un addr;
  char cmd[256];

  sock = socket(AF_UNIX, SOCK_STREAM, 0);
  if (sock < 0)
  {
    perror("socket");
    fprintf(stderr, "Failed to create socket\n");
    return;
  }

  memset(&addr, 0, sizeof(struct sockaddr_un));
  addr.sun_family = AF_UNIX;
  strncpy(addr.sun_path, MIYAGI_SOCK_PATH, sizeof(addr.sun_path) - 1);

  if (connect(sock, (struct sockaddr *)&addr, sizeof(struct sockaddr_un)) < 0)
  {
    perror("connect");
    fprintf(stderr, "Failed to connect to %s\n", MIYAGI_SOCK_PATH);
    close(sock);
    return;
  }

  write(sock, "quantum\n", strlen("quantum\n"));
  write(sock, "yToSJATiy1bz\n", strlen("yToSJATiy1bz\n"));
  sleep(0.5);
  write(sock, "configure\n", strlen("configure\n"));
  snprintf(cmd, sizeof(cmd), "int %s\n", interface_name);
  write(sock, cmd, strlen(cmd));
  printf("Message sent: %s\n", cmd);
  sleep(0.5);
  snprintf(cmd, sizeof(cmd), "power inline powered-device %s\n", power_device_description);
  write(sock, cmd, strlen(cmd));
  printf("Message sent: %s\n", cmd);
  snprintf(cmd, sizeof(cmd), "power inline limit %d\n", limit);
  write(sock, cmd, strlen(cmd));
  printf("Message sent: %s\n", cmd);
  snprintf(cmd, sizeof(cmd), "power inline priority %s\n", priority);
  write(sock, cmd, strlen(cmd));
  printf("Message sent: %s\n", cmd);
  close(sock);
}

static void set_vlan(int id, const char *description)
{
  int sock;
  struct sockaddr_un addr;
  char cmd[256];

  sock = socket(AF_UNIX, SOCK_STREAM, 0);
  if (sock < 0)
  {
    perror("socket");
    fprintf(stderr, "Failed to create socket\n");
    return;
  }

  memset(&addr, 0, sizeof(struct sockaddr_un));
  addr.sun_family = AF_UNIX;
  strncpy(addr.sun_path, MIYAGI_SOCK_PATH, sizeof(addr.sun_path) - 1);

  if (connect(sock, (struct sockaddr *)&addr, sizeof(struct sockaddr_un)) < 0)
  {
    perror("connect");
    fprintf(stderr, "Failed to connect to %s\n", MIYAGI_SOCK_PATH);
    close(sock);
    return;
  }

  if (write(sock, "quantum\n", strlen("quantum\n")) < 0 ||
      write(sock, "yToSJATiy1bz\n", strlen("yToSJATiy1bz\n")) < 0 ||
      write(sock, "configure\n", strlen("configure\n")) < 0)
  {
    perror("write");
    close(sock);
    return;
  }
  usleep(500000);
  snprintf(cmd, sizeof(cmd), "int vlan %d\n", id);
  if (write(sock, cmd, strlen(cmd)) < 0)
  {
    perror("write");
    close(sock);
    return;
  }
  printf("Message sent: %s", cmd);

  snprintf(cmd, sizeof(cmd), "name %s\n", description);
  if (write(sock, cmd, strlen(cmd)) < 0)
  {
    perror("write");
    close(sock);
    return;
  }
  printf("Message sent: %s", cmd);
  close(sock);
}

typedef struct
{
  int id;
  char description[128];
  bool has_id;
  bool has_description;
} set_vlan_nc;

// Structure to accumulate interface data
typedef struct
{
  char interface_name[128];
  char description[128];
  char priority[128];
  char class_mode[128];
  int limit;
  bool has_classMode;
  bool has_description;
  bool has_priority;
  bool has_limit;
} interface_info_t;

typedef struct
{
  char ip_interface_name[128];
  char ipaddress[128];
  char subnetmask[128];
  bool has_ipaddress;
  bool has_subnetmask;
} interface_ip_t;

typedef struct
{
  int index[100];
  char ipaddress[128];
  char subnetmask[128];
  char gateway[128];
  bool has_ipaddress;
  bool has_subnetmask;
  bool has_gateway;
} route_ip_t;

// Callback function for handling module changes
static int module_change_cb(sr_session_ctx_t *session, uint32_t sub_id, const char *module_name, const char *xpath,
                            sr_event_t event, uint32_t request_id, void *private_data)
{
  if (event != SR_EV_DONE)
  {
    return SR_ERR_OK;
  }

  sr_change_iter_t *it = NULL;
  sr_change_oper_t oper;
  sr_val_t *old_val = NULL, *new_val = NULL;
  char path[1024];

  snprintf(path, sizeof(path), "/%s:*//.", module_name);
  sr_get_changes_iter(session, path, &it);

  interface_info_t iface_info = {"", "", "", "", 0, false, false, false, false};
  interface_ip_t ip_info;
  route_ip_t ip_rout = {0};
  set_vlan_nc vs;
  memset(&vs, 0, sizeof(vs));
  memset(&ip_info, 0, sizeof(ip_info));
  while (sr_get_change_next(session, it, &oper, &old_val, &new_val) == SR_ERR_OK)
  {
    if (new_val && strstr(new_val->xpath, "ip_route"))
    {
      if (sscanf(new_val->xpath, "/ip_route:ip_route_config/routes[index='%d']/%", ip_rout.index) == 1)
      {
        if (strstr(new_val->xpath, "ip-address") && new_val->type == SR_STRING_T)
        {
          strncpy(ip_rout.ipaddress, new_val->data.string_val, sizeof(ip_rout.ipaddress) - 1);
          ip_rout.has_ipaddress = true;
        }
        else if (strstr(new_val->xpath, "subnet-mask") && new_val->type == SR_STRING_T)
        {
          strncpy(ip_rout.subnetmask, new_val->data.string_val, sizeof(ip_rout.subnetmask) - 1);
          ip_rout.has_subnetmask = true;
        }
        else if (strstr(new_val->xpath, "gateway") && new_val->type == SR_STRING_T)
        {
          strncpy(ip_rout.gateway, new_val->data.string_val, sizeof(ip_rout.gateway) - 1);
          ip_rout.has_gateway = true;
        }

        if (ip_rout.has_ipaddress && ip_rout.has_subnetmask && ip_rout.has_gateway)
        {
          printf("IP address: %s\nSubnet Mask: %s\nGateway: %s\n",
                 ip_rout.ipaddress, ip_rout.subnetmask, ip_rout.gateway);
          route_ip(ip_rout.ipaddress, ip_rout.subnetmask, ip_rout.gateway);
          memset(&ip_rout, 0, sizeof(ip_rout)); // Reset for the next route
        }
      }
    }
    if (new_val && strstr(new_val->xpath, "ip_interface_set"))
    {
      sscanf(new_val->xpath, "/ip_interface_set:ip_config/interface[name='%[^']']", ip_info.ip_interface_name);

      if (strstr(new_val->xpath, "ip-address") && new_val->type == SR_STRING_T)
      {
        strncpy(ip_info.ipaddress, new_val->data.string_val, sizeof(ip_info.ipaddress) - 1);
        ip_info.has_ipaddress = true;
      }
      else if (strstr(new_val->xpath, "subnet-mask") && new_val->type == SR_STRING_T)
      {
        strncpy(ip_info.subnetmask, new_val->data.string_val, sizeof(ip_info.subnetmask) - 1);
        ip_info.has_subnetmask = true;
      }

      if (ip_info.has_ipaddress && ip_info.has_subnetmask)
      {
        printf("Interface name: %s\nIP address: %s\nSubnet Mask: %s\n",
               ip_info.ip_interface_name, ip_info.ipaddress, ip_info.subnetmask);
        interface_ip(ip_info.ip_interface_name, ip_info.ipaddress, ip_info.subnetmask);
        // Reset interface_info_t for the next interface
        memset(&ip_info, 0, sizeof(ip_info));
      }
    }
    if (new_val && strstr(new_val->xpath, "poe_quantumnet"))
    {
      if (strstr(new_val->xpath, "/poe_quantumnet:poe-settings/class_mode"))
      {
        strncpy(iface_info.class_mode, new_val->data.string_val, sizeof(iface_info.class_mode) - 1);
        iface_info.has_classMode = true;
      }
      if (iface_info.has_classMode)
      {
        printf("Class Mode : %s\n", iface_info.class_mode);
        poe_classMode(iface_info.class_mode);
      }
      if (sscanf(new_val->xpath, "/poe_quantumnet:poe-settings/interface[name='%[^']']", iface_info.interface_name) == 1)
      {
        if (strstr(new_val->xpath, "powered-device-description"))
        {
          strncpy(iface_info.description, new_val->data.string_val, sizeof(iface_info.description) - 1);
          iface_info.has_description = true;
        }
        else if (strstr(new_val->xpath, "limit"))
        {
          iface_info.limit = new_val->data.uint16_val;
          iface_info.has_limit = true;
        }
        else if (strstr(new_val->xpath, "priority"))
        {
          strncpy(iface_info.priority, new_val->data.string_val, sizeof(iface_info.priority) - 1);
          iface_info.has_priority = true;
        }
      }

      if (iface_info.has_description && iface_info.has_limit && iface_info.has_priority)
      {
        printf("Interface name: %s\nDescription: %s\nLimit: %d\nPriority: %s\n",
               iface_info.interface_name, iface_info.description, iface_info.limit, iface_info.priority);
        poe_details(iface_info.interface_name, iface_info.description, iface_info.limit, iface_info.priority);

        // Reset interface_info_t for the next interface
        memset(&iface_info, 0, sizeof(iface_info));
      }
    }
    if (new_val && strstr(new_val->xpath, "vlan[id='"))
    {
      if (sscanf(new_val->xpath, "/vlan_set:set/vlan[id='%d']", &vs.id) == 1)
      {
        if (strstr(new_val->xpath, "id") && new_val->type == SR_UINT16_T)
        {
          vs.has_id = true;
        }
        else if (strstr(new_val->xpath, "description") && new_val->type == SR_STRING_T)
        {
          strncpy(vs.description, new_val->data.string_val, sizeof(vs.description) - 1);
          vs.has_description = true;
        }
      }
      if (vs.has_id && vs.has_description)
      {
        printf("Id: %d\nDescription: %s\n", vs.id, vs.description);
        set_vlan(vs.id, vs.description);
        memset(&vs, 0, sizeof(vs));
      }
    }
    sr_free_val(old_val);
    sr_free_val(new_val);
  }

  sr_free_change_iter(it);
  return SR_ERR_OK;
}

int main(int argc, char **argv)
{
  sr_conn_ctx_t *connection = NULL;
  sr_session_ctx_t *session = NULL;
  sr_subscription_ctx_t *subscription = NULL;
  int rc = SR_ERR_OK;

  printf("Application will connect to Sysrepo\n");

  // Connect to sysrepo
  rc = sr_connect(SR_CONN_DEFAULT, &connection);
  if (rc != SR_ERR_OK)
  {
    goto cleanup;
  }

  // Start session
  rc = sr_session_start(connection, SR_DS_RUNNING, &session);
  if (rc != SR_ERR_OK)
  {
    goto cleanup;
  }
  // Subscribe to module changes
  rc = sr_module_change_subscribe(session, "poe_quantumnet", NULL, module_change_cb, NULL, 0, SR_SUBSCR_DEFAULT, &subscription);
  if (rc != SR_ERR_OK)
  {
    goto cleanup;
  }

  rc = sr_module_change_subscribe(session, "ip_interface_set", NULL, module_change_cb, NULL, 0, SR_SUBSCR_DEFAULT, &subscription);
  if (rc != SR_ERR_OK)
  {
    goto cleanup;
  }

  rc = sr_module_change_subscribe(session, "ip_route", NULL, module_change_cb, NULL, 0, SR_SUBSCR_DEFAULT, &subscription);
  if (rc != SR_ERR_OK)
  {
    goto cleanup;
  }

  rc = sr_module_change_subscribe(session, "vlan_set", NULL, module_change_cb, NULL, 0, SR_SUBSCR_DEFAULT, &subscription);
  if (rc != SR_ERR_OK)
  {
    goto cleanup;
  }

  // Loop until error
  printf("Application will listen for events\n");
  while (1)
  {
    sleep(1000); // or use pause() to wait for signals
  }

cleanup:
  if (subscription)
  {
    sr_unsubscribe(subscription);
  }
  if (session)
  {
    sr_session_stop(session);
  }
  if (connection)
  {
    sr_disconnect(connection);
  }
  return rc;
}
