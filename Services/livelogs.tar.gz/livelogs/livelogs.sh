mkdir rootfs/ac3/etc/sv/livelogs
cp -vr qnos rootfs/ac3/etc/sv/livelogs
cd rootfs/ac3/etc/runit/runsvdir/default/
ln -s /etc/sv/livelogs livelogs
